/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AppSettings, CaseQuestion, ExerciseTimerCfg, Word } from '../types';
import { CASEQ, P6 } from '../data/seed';
import { checkSynAnt, checkWord, familyCands, fullWord, getCategories, intervalPreview, isAdjPos, isLeech, isNounPos, isVerbPos, nz, nz2, getTimerCfg } from '../utils/storage';
import { EXTRA_CASEQ, adjSourceByCode, adjSources, analyzeMistake, buildAdjItem, closestAnswer, parseSpec, randomSpec, specToString } from '../utils/grammar';
import { speak, stopSpeaking } from '../utils/audio';
import { checkConjAnswer, splitConj } from '../utils/conjugation';

/** Splits the six forms into two rows of three: [1..3] left column, [4..6] right column. */
const splitConjColumns = (forms: string[]): [string[], string[]] =>
  [forms.slice(0, 3), forms.slice(3, 6)];

import { WordDetailModal } from '../components/WordDetailModal';
import { SentenceBuilderModal } from '../components/SentenceBuilderModal';
import { SchreibenCorrector } from '../components/SchreibenCorrector';
import { Diktat } from '../components/SentenceDrills';
import { ErrorNotebook } from '../components/ErrorNotebook';
import { FreeSentencePractice, FREE_SENT_WORD } from '../components/FreeSentencePractice';
import { PageOverlay } from '../components/PageOverlay';
import { today } from '../utils/dates';
import { statusOf, STATUS_BADGE } from '../utils/wordStatus';
import { ShadowingModal } from '../components/ShadowingModal';
import { IconBtn } from '../components/IconBtn';
import { X, BookOpen, PencilLine, HelpCircle, Timer as TimerIcon, Mic, Sparkles } from 'lucide-react';
import { ConjugatedForm } from '../components/ConjugatedForm';
import { generateWithGemini, parseAI } from '../utils/ai';
import { HoerenTrainer } from '../components/HoerenTrainer';
import { SprechenTrainer } from '../components/SprechenTrainer';
import { LesenTrainer } from '../components/LesenTrainer';

// فاز ۴ #۵: PratText مشترک با هایلایت قرمزِ بخش تغییرکرده (بدون تعریف محلی)
import { PratText } from '../components/PratText';
import { trickOf } from '../utils/german';

export type ExerciseMode =
  | 'flash'
  | 'free'
  | 'daily'
  | 'review'
  | 'cloze'
  | 'vmix'
  | 'vmc'
  | 'act'
  | 'art'
  | 'dict'
  | 'plural'
  | 'conj'
  | 'tense'
  | 'case'
  | 'adjdecl'
  | 'prod'
  | 'synant'
  | 'n2v'
  | 'v2n'
  | 'hard'
  | 'sent'
  | 'freesent'
  | 'schreiben'
  | 'schreiben_exam'
  | 'puzzle'
  | 'dikt'
  | 'errnb'
  | 'vprep'
  | 'konnektoren'
  | 'tstory'
  | 'kpro'
  | 'wsh'
  | 'wsh2'
  | 'hoeren'
  | 'hoeren_new'
  | 'hoeren_archive';

export const EXERCISE_NAMES: Record<ExerciseMode, { title: string; icon: string; desc: string }> = {
  flash: { title: 'فلش‌کارت', icon: '🃏', desc: 'کارت واژه با الگوریتم تکرار فاصله‌دار لایتنر' },
  free: { title: 'مرور آزاد دسته', icon: '📚', desc: 'مرور همهٔ واژگان یک دسته، بدون محدودیت و بدون اثر بر لایتنر' },
  daily: { title: 'جلسهٔ روزانه', icon: '🌟', desc: 'سررسیدها + واژه‌های جدید متناسب با سهمیه روزانه' },
  review: { title: 'مرور سررسیدها', icon: '🔁', desc: 'فقط واژه‌هایی که تاریخ مرور آن‌ها فرا رسیده' },
  cloze: { title: 'جای‌خالی', icon: '✍️', desc: 'تکمیل جمله با واژه یا عبارت درست' },
  vmix: { title: 'تمرین دوگانه (فعال/دریافتی)', icon: '🧠', desc: 'فعال‌ها معادل آلمانی را تایپ می‌کنند؛ دریافتی‌ها معنی را انتخاب می‌کنند — آمار جداگانه و ارتقای خودکار' },
  vmc: { title: 'انتخاب معنی (زیرمد)', icon: '👁', desc: 'زیرمد شناختی تمرین دوگانه — مستقیم انتخاب نمی‌شود' },
  act: { title: 'فعال‌سازی (کاندید → فعال)', icon: '🚀', desc: 'فقط واژه‌های کاندید — معنی را می‌بینی، معادل آلمانی را می‌نویسی؛ ۳ برداشت پیاپی = آمادهٔ ارتقا به فعال' },
  art: { title: 'آرتیکل', icon: '🎨', desc: 'تشخیص der / die / das برای اسامی' },
  dict: { title: 'دیکته واژه', icon: '🔊', desc: 'تمرین شنیدار و تشخیص واژگان از روی صدا' },
  plural: { title: 'جمع اسم‌ها', icon: '🔢', desc: 'نوشتن شکل جمع اسامی آلمانی' },
  conj: { title: 'صرف فعل', icon: '🔤', desc: 'صرف فعل برای ضمایر مختلف با هایلایت پایانه و تغییر ریشه' },
  tense: { title: 'زمان فعل', icon: '⏳', desc: 'تمرین زمان‌های Präteritum و Perfekt' },
  case: { title: 'حالت و حرف اضافه', icon: '🧩', desc: 'دو جای خالی مجزا برای حرف اضافه و آرتیکل' },
  adjdecl: { title: 'صرف صفت', icon: '🧱', desc: 'نوشتن شکل درست صفت (پایانه) با آرتیکل، حالت و جنس مختلف' },
  prod: { title: 'فارسی ← آلمانی (تایپی)', icon: '🔁', desc: 'دیدن ترجمه و نوشتن کامل واژه آلمانی' },
  synant: { title: 'مترادف و متضاد', icon: '↔️', desc: 'نوشتن مترادف یا متضاد واژهٔ داده‌شده' },
  n2v: { title: 'اسم ← فعل', icon: '🔁', desc: 'از روی اسم، فعل هم‌خانواده را بنویسید' },
  v2n: { title: 'فعل ← اسم', icon: '🂂', desc: 'از روی فعل، اسم هم‌خانواده را (با آرتیکل) بنویسید' },
  hard: { title: 'تمرین ترکیبی واژه‌های سخت', icon: '🩸', desc: 'هر واژهٔ سخت در قالب‌های مختلف و با چیدمان تصادفی' },
  sent: { title: 'تولید جمله', icon: '🗣', desc: 'جمله‌سازی با واژه و بررسی ساختار' },
  freesent: { title: 'تولید جملهٔ آزاد', icon: '✒️', desc: 'هر جمله‌ای بساز؛ تصحیح کامل گرامر، حروف ربط، حرف اضافه و حالت، آرتیکل و صرف صفت با نمره' },
  schreiben: { title: 'Schreiben prüfen', icon: '📸', desc: 'عکس دست‌نویس (چند صفحه)، فایل یا متن خودت را بفرست؛ تصحیح کامل با تفکر آلمانی، سبک و گرامر' },
  schreiben_exam: { title: 'Schreiben Prüfung', icon: '📝', desc: 'انتخاب سطح و سناریوی استاندارد آزمون (ایمیل رسمی، وبلاگ، درخواست کار) و نمره‌دهی' },
  puzzle: { title: 'چیدن جمله (Satzbau)', icon: '🧩', desc: 'انتخاب نوع جمله‌ها (خودت یا ساخت با هوش مصنوعی + سطح و تعداد)؛ کلمه‌های درهم‌ریخته را به ترتیب درست آلمانی بچین' },
  dikt: { title: 'دیکته جمله', icon: '🎧', desc: 'جمله را بشنو و دقیق بنویس؛ تصحیح کلمه‌به‌کلمه' },
  errnb: { title: 'دفتر خطاها', icon: '📓', desc: 'جمله‌های غلطِ خودت (از تصحیح نوشتار) با مرور فاصله‌دار؛ خطاها تکرار نشوند' },
  vprep: { title: 'فعل + حرف اضافه (Verben mit Präpositionen)', icon: '🔗', desc: '۱۰۰+ فعل مهم با حرف اضافه و حالت دستوری؛ سه تمرین جدا: یادگیری با فیلتر و مثال لمس‌پذیر، تمرین فاصله‌دار و افزودن فعل جدید' },
  konnektoren: { title: 'متن جای‌خالی (Konnektoren)', icon: '📝', desc: 'متن جای‌خالی با حروف ربط؛ سطح و تعداد جای خالی را انتخاب کن تا AI هر بار متن تازه بسازد؛ کشیدن/کلیک کلمه‌ها، تصحیح فوری، چت با معلم، چاپ دو صفحه‌ای و آرشیو' },
  tstory: { title: 'داستان همهٔ زمان‌ها', icon: '📖', desc: 'مثل تمرین کتاب: داستان کوتاه با جاهای خالی فعل؛ سطح A1 تا C2 و همهٔ زمان‌ها + ذخیره و چاپ' },
  kpro: { title: 'حرف ربط انتخابی', icon: '🤖', desc: 'شروع جمله و حرف ربط داده‌شده را کامل کن؛ حروف ربط را می‌توانی خودت انتخاب کنی (یکی یا چندتا از همهٔ سطوح)؛ تصحیح سه‌لایه، ترجمهٔ فارسی بعد از بررسی، گفتگو با معلم، آزمون دوباره و چاپ — سطح A1 تا C2' },
  wsh: { title: 'جای‌خالی فعل + حرف اضافه (AI)', icon: '📄', desc: 'هوش مصنوعی هر بار با سطح و تعدادِ انتخابیِ تو یک برگهٔ جای‌خالی فعل+حرف اضافه می‌سازد؛ بررسی فوری، «چرا این جواب؟»، ترجمهٔ فارسی بعد از بررسی، چت با معلم، تولید جملهٔ آزاد و چاپ کل برگه' },
  wsh2: { title: 'تکمیل جمله', icon: '🧾', desc: 'طرف اول جمله + حرف ربطِ انتها را می‌بینی و ادامهٔ جمله را با جایگاه فعل درست می‌نویسی؛ تصحیح با AI، ترجمهٔ فارسی بعد از بررسی، چت با معلم و آرشیو' },
  hoeren: { title: 'Hörverstehen', icon: '🎧', desc: 'Hörtexte, Richtig/Falsch und Lückentexte' },
  hoeren_new: { title: 'ساخت تمرین جدید', icon: '✨', desc: 'متن را وارد کن؛ تمرین شنیداری، سؤال‌ها و فایل صوتی ساخته می‌شود' },
  hoeren_archive: { title: 'تمرینات قبلی (آرشیو)', icon: '📂', desc: 'تمرین‌های ذخیره‌شده را دوباره انجام بده' }
};

const WORTSCHATZ_MODES: ExerciseMode[] = ['flash', 'vmix', 'act', 'review', 'daily', 'free', 'sent', 'cloze', 'prod', 'n2v', 'v2n', 'synant', 'plural'];
/** ساختار دو سطحی تب گرامر: ۴ دستهٔ اصلی؛ هر تمرین یک تب مستقل (بدون زیربخش داخلی) */
interface GramTab { id: string; label: string; mode: ExerciseMode; vTab?: 'learn' | 'practice' | 'add' }
interface GramCat { icon: string; label: string; desc: string; tabs: GramTab[] }
const GRAMMATIK_CATS: GramCat[] = [
  {
    icon: '🔤', label: 'فعل و زمان‌ها', desc: 'صرف فعل، زمان‌های Präteritum و Perfekt، داستان با همهٔ زمان‌ها',
    tabs: [
      { id: 'conj', label: 'صرف فعل', mode: 'conj' },
      { id: 'tense', label: 'زمان فعل', mode: 'tense' },
      { id: 'tstory', label: 'داستان زمان‌ها', mode: 'tstory' },
    ],
  },
  {
    icon: '🧱', label: 'اسم، آرتیکل، صفت و حالت', desc: 'der/die/das، پایانهٔ صفت، حرف اضافه + حالت',
    tabs: [
      { id: 'art', label: 'آرتیکل', mode: 'art' },
      { id: 'adjdecl', label: 'صرف صفت', mode: 'adjdecl' },
      { id: 'case', label: 'حالت و حرف اضافه', mode: 'case' },
    ],
  },
  {
    icon: '🔗', label: 'حروف اضافه', desc: 'فعل + حرف اضافه: یادگیری، تمرین فاصله‌دار و افزودن فعل؛ جای‌خالی فعل+حرف اضافه و تکمیل جمله',
    tabs: [
      { id: 'vprepl', label: 'یادگیری فعل‌ها', mode: 'vprep', vTab: 'learn' },
      { id: 'vprepp', label: 'تمرین فعل‌ها', mode: 'vprep', vTab: 'practice' },
      // «افزودن فعل» از ردیف بالا حذف شد — دکمهٔ آن پایین فهرست یادگیری است و پاپ‌آپ باز می‌کند (درخواست کاربر)
      { id: 'wsh', label: 'جای‌خالی فعل+حرف اضافه', mode: 'wsh' },
      { id: 'wsh2', label: 'تکمیل جمله', mode: 'wsh2' },
    ],
  },
  {
    icon: '🧩', label: 'حروف ربط و جمله‌سازی', desc: 'متن جای‌خالی با حروف ربط، حرف ربط انتخابی و چیدن جمله',
    tabs: [
      { id: 'konnektoren', label: 'متن جای‌خالی', mode: 'konnektoren' },
      { id: 'kpro', label: 'حرف ربط انتخابی', mode: 'kpro' },
      { id: 'puzzle', label: 'چیدن جمله', mode: 'puzzle' },
    ],
  },
];
const SCHREIBEN_MODES: ExerciseMode[] = ['schreiben', 'schreiben_exam', 'freesent', 'errnb'];
const HOEREN_MODES: ExerciseMode[] = ['hoeren_new', 'hoeren_archive', 'dict', 'dikt'];
type MainTab = 'flash' | 'wortschatz' | 'grammatik' | 'schreiben' | 'hoeren' | 'sprechen' | 'lesen';

const MAIN_TABS: { id: MainTab; icon: string; label: string }[] = [
  { id: 'flash', icon: '🃏', label: 'Lernkarten' },
  { id: 'wortschatz', icon: '📚', label: 'Wortschatz' },
  { id: 'grammatik', icon: '🧩', label: 'Grammatik' },
  { id: 'schreiben', icon: '✍️', label: 'Schreiben' },
  { id: 'hoeren', icon: '🎧', label: 'Hören' },
  { id: 'sprechen', icon: '🗣️', label: 'Sprechen' },
  { id: 'lesen', icon: '📖', label: 'Lesen' }
];

const isSelfContainedMode = (m: ExerciseMode | null): boolean =>
  m === 'freesent' || m === 'schreiben' || m === 'schreiben_exam' || m === 'puzzle' || m === 'dikt' || m === 'errnb' || m === 'vprep' || m === 'hoeren' || m === 'konnektoren' || m === 'tstory' || m === 'kpro' || m === 'wsh' || m === 'wsh2';

/** تمرین‌های خودگردان گرامر — بدنهٔ آن‌ها در لایهٔ keep-alive در App.tsx رندر می‌شود
 *  تا با جابجایی تب‌ها باز بمانند (تا وقتی کاربر ضربدر را نزده). */
const GRAM_SELF_MODES: ExerciseMode[] = ['vprep', 'wsh', 'wsh2', 'konnektoren', 'kpro', 'tstory', 'puzzle'];
const isGramSelfMode = (m: ExerciseMode | null): boolean => !!m && GRAM_SELF_MODES.includes(m);

export const HighlightedVerbForm: React.FC<{
  verb: string;
  form: string;
  pronounIndex: number;
  sep?: string;
}> = ({ verb, form, pronounIndex, sep }) => (
  <ConjugatedForm verb={verb} form={form} pronounIndex={pronounIndex} sep={sep} />
);

interface MistakeComparisonProps {
  user: string;
  expected: string | string[];
  label?: string;
}

export const MistakeComparison: React.FC<MistakeComparisonProps> = ({ user, expected, label }) => {
  const report = useMemo(() => {
    const list = Array.isArray(expected) ? expected : [expected];
    const target = closestAnswer(user, list) || (list[0] || '');
    return analyzeMistake(user, target);
  }, [user, expected]);

  if (!report.expected) return null;

  return (
    <div className="p-3.5 rounded-xl bg-white dark:bg-[#141923] border border-red-200 dark:border-red-900/60 text-right space-y-2 text-sm md:text-base">
      <div className="font-bold text-slate-700 dark:text-slate-200">
        🔍 مقایسهٔ پاسخ شما با شکل درست{label ? ` — ${label}` : ''}
      </div>

      <div className="flex flex-wrap items-baseline gap-2">
        <span className="text-[#5d6676] dark:text-[#a3adbd] font-semibold flex-shrink-0">نوشتهٔ شما:</span>
        <span dir="ltr" className="font-sans font-bold text-base tracking-wide break-all">
          {report.user === '' ? (
            <span className="text-red-600 dark:text-red-400">—</span>
          ) : (
            report.segments.map((seg, i) =>
              seg.kind === 'eq' ? (
                <span key={i} className="text-slate-900 dark:text-slate-100">{seg.usr}</span>
              ) : seg.usr ? (
                <span
                  key={i}
                  className="text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-950/60 rounded-sm underline decoration-wavy"
                >
                  {seg.usr.replace(/ /g, '\u00a0')}
                </span>
              ) : (
                <span key={i} className="text-red-600 dark:text-red-400 font-extrabold" title="حرف جا افتاده">
                  _
                </span>
              )
            )
          )}
        </span>
      </div>

      <div className="flex flex-wrap items-baseline gap-2">
        <span className="text-[#5d6676] dark:text-[#a3adbd] font-semibold flex-shrink-0">شکل درست:</span>
        <span dir="ltr" className="font-sans font-bold text-base tracking-wide break-all">
          {report.segments.map((seg, i) =>
            seg.kind === 'eq' ? (
              <span key={i} className="text-slate-900 dark:text-slate-100">{seg.exp}</span>
            ) : seg.exp ? (
              <span
                key={i}
                className="text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/60 rounded-sm underline"
              >
                {seg.exp.replace(/ /g, '\u00a0')}
              </span>
            ) : null
          )}
        </span>
      </div>

      <div className="pt-1 border-t border-slate-200/70 dark:border-slate-800">
        <div className="font-bold text-red-600 dark:text-red-400 mb-1">اشتباه شما:</div>
        <ul className="space-y-0.5 text-slate-800 dark:text-slate-200 leading-relaxed">
          {report.notes.map((note, i) => (
            <li key={i} className="flex items-start gap-1.5">
              <span className="text-red-500 mt-0.5">•</span>
              <span>{note}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const maskText = (text: string, level: number): string =>
  text
    .split(' ')
    .map(tok => {
      const chars = [...tok];
      if (chars.length <= 1) return tok;
      if (chars.length === 2) return level >= 2 ? tok : `${chars[0]} _`;
      const head = level >= 2 ? 2 : 1;
      const tail = level >= 2 ? 1 : 0;
      return chars.map((c, i) => (i < head || i >= chars.length - tail ? c : '_')).join(' ');
    })
    .join('   ');

interface HintInfo {
  note: string;
  mask: string;
}

const buildHint = (
  mode: string,
  w: Word,
  level: number,
  ctx: { pron: number; kind: string; cands: string[] }
): HintInfo => {
  const len = (t: string) => `${[...t.replace(/ /g, '')].length} حرف`;
  let target = '';
  const notes: string[] = [];

  switch (mode) {
    case 'cloze': {
      target = w.ans || w.de;
      const imp: [string, string | undefined][] = [['du', w.imperativDu], ['ihr', w.imperativIhr], ['Sie', w.imperativSie]];
      const hit = isVerbPos(w.pos) ? imp.find(([, v]) => v && nz(v.replace(/[!.]/g, '')) === nz(target.replace(/[!.]/g, ''))) : undefined;
      if (hit) notes.push(`شکل امری برای ضمیر «${hit[0]}»`);
      else if (isVerbPos(w.pos)) notes.push('فعل باید با فاعل جمله صرف شود');
      else if (isAdjPos(w.pos)) notes.push('صفت باید با پایانهٔ مناسب جمله صرف شود');
      break;
    }
    case 'dict':
    case 'prod': {
      target = fullWord(w);
      if (w.art) notes.push('اسم است؛ آرتیکل را هم بنویسید');
      else if (isVerbPos(w.pos)) notes.push('مصدر فعل را بنویسید');
      break;
    }
    case 'plural':
      target = (w.pl || '').replace(/^die\s+/i, '');
      notes.push('شکل جمع (بدون آرتیکل هم قبول است)');
      break;
    case 'conj': {
      const forms = splitConj(w.conj || '');
      target = (forms[ctx.pron] || forms[2] || '').trim();
      notes.push(`شکل فعل برای «${P6[ctx.pron]}»`);
      break;
    }
    case 'tense':
      target = w.prat || w.perf || '';
      notes.push(w.prat ? 'Präteritum' : 'Perfekt');
      break;
    case 'adjdecl':
      target = ctx.cands[0] || '';
      notes.push('صفت قبل از اسم پایانه می‌گیرد؛ نوع آرتیکل، حالت و جنس اسم را بررسی کنید');
      break;
    case 'synant':
    case 'n2v':
    case 'v2n': {
      target = ctx.cands[0] || '';
      notes.push(`${ctx.cands.length} پاسخ ممکن است`);
      if (level >= 2 && mode === 'synant') {
        const fa = ctx.kind === 'ant' ? w.antFa : w.synFa;
        if (fa) notes.push(`ترجمهٔ فارسی: ${fa}`);
      }
      break;
    }
    default:
      target = w.de;
  }

  if (target) notes.push(len(target));
  return { note: notes.join(' • '), mask: target ? maskText(target, level) : '' };
};

const germanTokens = (t: string): string[] => t.split(/[^\p{L}]+/u).filter(Boolean);

export function findWordInSentence(w: Word, sentence: string): string {
  const tokens = germanTokens(sentence);
  const low = tokens.map(t => t.toLowerCase());
  const base = (w.de || '').replace(/^sich\s+/i, '').trim().toLowerCase();
  if (!base) return '';
  const forms = new Set<string>([base]);
  const lastTok = (x: string) => germanTokens(x).pop()?.toLowerCase() || '';

  if (isVerbPos(w.pos)) {
    splitConj(w.conj || '').forEach(f => { const t = lastTok(f); if (t) forms.add(t); });
    [w.prat, w.perf].forEach(f => { const t = lastTok(f || ''); if (t) forms.add(t); });
    const sep = (w.sep || '').trim().toLowerCase();
    const core = sep && base.startsWith(sep) ? base.slice(sep.length) : base;
    const stem = core.replace(/(en|n)$/, '');
    const hit = low.findIndex(t => forms.has(t) || (stem.length >= 3 && (t.includes(stem) || (stem.length >= 4 && t.startsWith(stem.slice(0, stem.length - 1))))));
    if (hit >= 0) return tokens[hit];
  } else if (isAdjPos(w.pos)) {
    const hit = low.findIndex(t => t.startsWith(base) && t.length - base.length <= 2);
    if (hit >= 0) return tokens[hit];
  } else {
    const pl = (w.pl || '').replace(/^die\s+/i, '').trim().toLowerCase();
    if (pl && !pl.startsWith('-')) forms.add(pl);
    ['s', 'es', 'n', 'en'].forEach(e => forms.add(base + e));
    const hit = low.findIndex(t => forms.has(t));
    if (hit >= 0) return tokens[hit];
  }
  return '';
}

export interface SentenceCheck {
  used: string;
  items: { ok: boolean; text: string }[];
  grade: number;
}

export function checkSentence(w: Word, sentenceRaw: string): SentenceCheck {
  const sentence = sentenceRaw.trim();
  const used = findWordInSentence(w, sentence);
  const tokens = germanTokens(sentence);
  const isNoun = !!w.art || isNounPos(w.pos);
  const items: { ok: boolean; text: string }[] = [];
  items.push({
    ok: !!used,
    text: used ? `واژهٔ «${w.de}» در جمله استفاده شده است («${used}»).` : `واژهٔ «${w.de}» (یا شکل صرف‌شدهٔ آن) در جمله دیده نمی‌شود.`
  });
  items.push({ ok: tokens.length >= 3, text: tokens.length >= 3 ? 'جمله طول مناسب دارد.' : 'جمله خیلی کوتاه است؛ دست‌کم ۳ کلمه بنویسید.' });
  items.push({ ok: /^\p{Lu}/u.test(sentence), text: /^\p{Lu}/u.test(sentence) ? 'جمله با حرف بزرگ شروع شده است.' : 'جمله باید با حرف بزرگ شروع شود.' });
  items.push({ ok: /[.!?]$/.test(sentence), text: /[.!?]$/.test(sentence) ? 'پایان جمله علامت نگارشی دارد.' : 'در پایان جمله نقطه، علامت سؤال یا تعجب بگذارید.' });
  if (isNoun && used) {
    const capital = /^\p{Lu}/u.test(used);
    items.push({ ok: capital, text: capital ? 'اسم با حرف بزرگ نوشته شده است.' : `اسم «${w.de}» در آلمانی همیشه با حرف بزرگ نوشته می‌شود.` });
  }
  const allOk = items.every(i => i.ok);
  return { used, items, grade: used ? (allOk ? 2 : 1) : 0 };
}

const SentencePractice: React.FC<{
  w: Word;
  faVisible: boolean;
  faButton: React.ReactNode;
  timeUpSignal: number;
  onGraded: (grade: number) => void;
  onNext: () => void;
}> = ({ w, faVisible, faButton, timeUpSignal, onGraded, onNext }) => {
  const [text, setText] = useState('');
  const [result, setResult] = useState<SentenceCheck | null>(null);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiMsg, setAiMsg] = useState('');

  const runCheck = (force: boolean) => {
    if (result) return;
    if (!text.trim() && !force) return;
    const r = checkSentence(w, text);
    setResult(r);
    onGraded(text.trim() ? r.grade : 0);
  };

  const startSignal = useRef(timeUpSignal);
  useEffect(() => {
    if (timeUpSignal !== startSignal.current) runCheck(true);
  }, [timeUpSignal]);

  const askAi = async () => {
    if (!text.trim() || aiBusy) return;
    setAiBusy(true);
    setAiMsg('');
    try {
      const prompt = `You are a German teacher. A learner wrote one German sentence using the word "${fullWord(w)}" (meaning: ${w.fa}).
Sentence: ${text.trim()}
Check grammar, word order, cases, articles, verb forms and whether the target word is used correctly.
Also translate the corrected sentence into Persian.
Return ONLY valid JSON: [{"correct": true|false, "corrected": "corrected sentence (same as input if correct)", "fa": "ترجمهٔ فارسی جملهٔ درست‌شده", "explanation": "short explanation in Persian"}]`;
      const out = await generateWithGemini(prompt, { timeoutMs: 20000, retries: 0 });
      const r: any = parseAI(out)[0] || {};
      setAiMsg(
        `${r.correct ? '✔ از نظر هوش مصنوعی جمله درست است.' : '✘ پیشنهاد اصلاح: ' + (r.corrected || '')}${r.explanation ? '\n' + r.explanation : ''}${r.fa ? '\n\n🇮🇷 ترجمهٔ فارسی: ' + r.fa : ''}`
      );
    } catch (e: any) {
      setAiMsg('اتصال به هوش مصنوعی ممکن نشد؛ بررسی خودکار بالا همچنان معتبر است. (' + (e?.message || 'خطا') + ')');
    } finally {
      setAiBusy(false);
    }
  };

  return (
    <div className="space-y-3 text-right">
      <p className="text-sm font-semibold text-[#5d6676] dark:text-[#a3adbd] text-center">با این واژه یک جملهٔ آلمانی بنویسید:</p>
      <div className="text-2xl md:text-3xl font-extrabold text-center font-sans" dir="ltr">{fullWord(w)}</div>
      <div className="text-center text-base font-semibold text-[#1f5fbf] dark:text-[#7fb0ff]">{faVisible || result ? w.fa : faButton}</div>

      {!result ? (
        <>
          <textarea
            dir="ltr"
            rows={3}
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder="Schreiben Sie hier Ihren Satz …"
            className="w-full bg-slate-50 dark:bg-[#141923] border-2 border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 font-sans text-base outline-none"
          />
          <div className="flex gap-2">
            <button
              onClick={() => runCheck(false)}
              disabled={!text.trim()}
              className="flex-1 bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] disabled:opacity-40 text-white px-6 py-2.5 rounded-xl text-sm font-bold"
            >
              بررسی جمله
            </button>
          </div>
        </>
      ) : (
        <div className="space-y-3">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#141923] border border-[#dde1ea] dark:border-[#333b4a] font-sans text-base" dir="ltr">{text.trim() || '—'}</div>
          <ul className="space-y-1.5 text-sm leading-7">
            {result.items.map((it, i) => (
              <li key={i} className={it.ok ? 'text-emerald-700 dark:text-emerald-300' : 'text-red-600 dark:text-red-400 font-semibold'}>
                {it.ok ? '✔' : '✘'} {it.text}
              </li>
            ))}
          </ul>
          <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900 space-y-1.5 text-sm">
            <div className="font-bold">📚 جمله‌های نمونه برای مقایسه</div>
            {w.ex || w.ex2 ? (
              <>
                {w.ex && (<div><div dir="ltr" className="font-sans font-semibold text-left">{w.ex}</div><div className="text-[#5d6676] dark:text-[#a3adbd]">{w.exFa}</div></div>)}
                {w.ex2 && (<div><div dir="ltr" className="font-sans font-semibold text-left">{w.ex2}</div><div className="text-[#5d6676] dark:text-[#a3adbd]">{w.ex2Fa}</div></div>)}
              </>
            ) : (
              <div className="text-[#5d6676] dark:text-[#a3adbd]">برای این واژه هنوز جملهٔ نمونه ثبت نشده است.</div>
            )}
          </div>
          {aiMsg && <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-sm whitespace-pre-wrap leading-7">{aiMsg}</div>}
          <div className="flex gap-2">
            <button
              onClick={askAi}
              disabled={aiBusy || !text.trim()}
              className="px-4 py-2.5 rounded-xl text-sm font-bold bg-amber-100 text-amber-900 disabled:opacity-50"
            >
              {aiBusy ? 'در حال بررسی…' : '🤖 بررسی دستوری با هوش مصنوعی'}
            </button>
            <button onClick={onNext} className="flex-1 bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold">
              ادامه ◀
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export { getTimerCfg };

const shuffleArr = <T,>(arr: T[]): T[] => {
  const r = [...arr];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
};

const splitList = (s: string): string[] =>
  (s || '').split(/[,;،؛/|]/).map(x => x.trim()).filter(Boolean);

const ALL_CASEQ: CaseQuestion[] = [...CASEQ, ...EXTRA_CASEQ];

/** فاز ۲: سؤال شناختی واژهٔ دریافتی — انتخاب معنی از میان گزینه‌ها (زیرمد تمرین دوگانه) */
const VmcQuestion: React.FC<{
  w: Word;
  poolWords: Word[];
  onRecord: (w: Word, mode: string, grade: number) => void;
  advance: () => void;
  speakCfg?: { rate?: number; vreg?: string; voice?: string };
}> = ({ w, poolWords, onRecord, advance, speakCfg }) => {
  const [chosen, setChosen] = useState<string | null>(null);
  const options = useMemo(() => {
    const others = poolWords.filter(o => o.id !== w.id && o.fa && o.fa !== w.fa);
    const sameCat = others.filter(o => o.cat === w.cat);
    const pickFrom = sameCat.length >= 3 ? sameCat : others;
    const picked: string[] = [];
    for (const o of pickFrom.slice().sort(() => Math.random() - 0.5)) {
      if (picked.length >= 3) break;
      if (!picked.includes(o.fa)) picked.push(o.fa);
    }
    return [w.fa, ...picked].sort(() => Math.random() - 0.5);
  }, [w.id, w.fa, w.cat, poolWords]);
  const answered = chosen !== null;
  const ok = chosen === w.fa;
  const st = statusOf(w);

  return (
    <div className="space-y-4 text-center">
      <div className="flex items-center justify-center gap-2 flex-wrap">
        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${STATUS_BADGE[st]}`}>
          {st === 'passiv' ? 'دریافتی' : st === 'aktiv' ? 'فعال' : 'کاندید'}
        </span>
        <span className="text-xs text-[#5d6676]">معنی درست را انتخاب کن:</span>
      </div>
      <div className="flex items-center justify-center gap-3">
        <div className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-sans" dir="ltr">{fullWord(w)}</div>
        <button
          onClick={() => speak(fullWord(w), { rate: speakCfg?.rate, vreg: speakCfg?.vreg, voiceName: speakCfg?.voice })}
          className="w-10 h-10 rounded-full bg-[#1f5fbf] text-white text-lg flex items-center justify-center shadow-md hover:opacity-95"
        >🔊</button>
      </div>

      {!answered ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-md mx-auto pt-1">
          {options.map(op => (
            <button
              key={op}
              onClick={() => { setChosen(op); onRecord(w, 'vmc', op === w.fa ? 2 : 0); }}
              className="p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1b2029] hover:border-[#1f5fbf] text-sm font-bold text-slate-800 dark:text-slate-200 transition"
            >{op}</button>
          ))}
        </div>
      ) : (
        <div className="space-y-3 pt-1 max-w-md mx-auto">
          <div className={`p-3 rounded-xl text-base font-bold ${ok ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
            {ok ? '✔ درست است! آفرین.' : `✘ پاسخ درست: ${w.fa}`}
          </div>
          {w.ex && (
            <div className="p-2.5 bg-slate-50 dark:bg-[#141923] rounded-xl text-sm space-y-1">
              <p dir="ltr" className="font-sans font-semibold text-slate-800 dark:text-slate-200">{w.ex}</p>
              {w.exFa && <p className="text-[#5d6676]">{w.exFa}</p>}
            </div>
          )}
          <button
            onClick={advance}
            className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs"
          >سؤال بعدی ⬅</button>
        </div>
      )}
    </div>
  );
};

const pickCaseQueue = (): string[] => {
  const byLevel = new Map<number, CaseQuestion[]>();
  ALL_CASEQ.forEach(q => byLevel.set(q.cs || 1, [...(byLevel.get(q.cs || 1) || []), q]));
  const chosen: CaseQuestion[] = [];
  [...byLevel.keys()].sort().forEach(level => chosen.push(...shuffleArr(byLevel.get(level) || []).slice(0, 7)));
  return chosen.sort((a, b) => (a.cs || 1) - (b.cs || 1)).map(q => q.id);
};

const adjKey = (w: Word, level?: number): string | null => {
  const sources = adjSources(w, isAdjPos(w.pos));
  if (sources.length === 0) return null;
  const src = sources[Math.floor(Math.random() * sources.length)];
  const lv = level || [1, 1, 1, 2, 2, 2, 3, 3][Math.floor(Math.random() * 8)];
  for (let i = 0; i < 20; i++) {
    const spec = randomSpec(lv);
    if (buildAdjItem(src.base, spec)) return `${w.id}::adjdecl::${src.code}~${specToString(spec)}`;
  }
  return null;
};

const buildAdjQueue = (ws: Word[], n: number): string[] => {
  const adjWords = ws.filter(w => adjSources(w, isAdjPos(w.pos)).length > 0);
  if (adjWords.length === 0) return [];
  const out: string[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < n * 4 && out.length < n; i++) {
    const k = adjKey(adjWords[Math.floor(Math.random() * adjWords.length)]);
    if (k && !seen.has(k)) {
      seen.add(k);
      out.push(k);
    }
  }
  return out;
};

const synAntKey = (w: Word, sub = 'synant'): string => {
  const kinds: string[] = [];
  if (splitList(w.syn).length) kinds.push('syn');
  if (splitList(w.ant).length) kinds.push('ant');
  const kind = kinds[Math.floor(Math.random() * kinds.length)] || 'syn';
  return `${w.id}::${sub}::${kind}`;
};

const buildHardQueue = (ws: Word[], limit = 20): string[] => {
  const day = Math.floor(Date.now() / 86400000);
  const mk = (w: Word, sub: string) => sub === 'synant' ? synAntKey(w) : sub === 'adjdecl' ? adjKey(w) : `${w.id}::${sub}`;
  const subsFor = (w: Word): string[] => {
    const subs = ['flashDe', 'flashFa', 'dict', 'prod'];
    if (w.cloze || w.ans) subs.push('cloze');
    if (w.art) subs.push('art');
    if (w.pl) subs.push('plural');
    if (w.conj) subs.push('conj');
    if (w.prat || w.perf) subs.push('tense');
    if (splitList(w.syn).length || splitList(w.ant).length) subs.push('synant');
    if (isAdjPos(w.pos) && adjSources(w, true).length > 0) subs.push('adjdecl');
    return subs;
  };
  const sorted = [...ws].sort((a, b) => (b.bad || 0) - (a.bad || 0));
  const n = sorted.length;
  const chosen = n > limit ? Array.from({ length: limit }, (_, i) => sorted[(day * limit + i) % n]) : sorted;
  const rotated = chosen.map((w, wi) => { const s0 = subsFor(w); const off = (day + wi) % s0.length; return [...s0.slice(off), ...s0.slice(0, off)]; });
  const keys: string[] = [];
  for (let round = 0; keys.length < limit; round++) {
    let added = false;
    for (let wi = 0; wi < chosen.length && keys.length < limit; wi++) {
      const sub = rotated[wi][round];
      if (!sub) continue;
      const key = mk(chosen[wi], sub);
      if (key) { keys.push(key); added = true; }
    }
    if (!added) break;
  }
  const idOf = (k: string) => k.split('::')[0];
  const subOf = (k: string) => k.split('::')[1];
  const rest = shuffleArr(keys);
  const out: string[] = [];
  while (rest.length) {
    const prev = out[out.length - 1];
    let idx = rest.findIndex(k => !prev || (idOf(k) !== idOf(prev) && subOf(k) !== subOf(prev)));
    if (idx < 0) idx = rest.findIndex(k => !prev || idOf(k) !== idOf(prev));
    if (idx < 0) idx = 0;
    out.push(rest.splice(idx, 1)[0]);
  }
  return out;
};

interface ExercisesViewProps {
  words: Word[];
  settings?: AppSettings;
  activeMode: ExerciseMode | null;
  practiceWordIds?: string[] | null;
  onSelectMode: (mode: ExerciseMode | null) => void;
  onRecordResult: (word: Word | CaseQuestion, mode: string, grade: number, isRetry: boolean) => void;
  onOpenHelp: (topic: string) => void;
  onShowToast: (msg: string, isErr?: boolean) => void;
  onEditWord?: (word: Word) => void;
  onDeleteWord?: (word: Word) => void;
  onImageChange?: (word: Word, newImg: string) => void;
  paused?: boolean;
  onUpdateSettings?: (patch: Partial<AppSettings>) => void;
  onStartHard?: (ids: string[]) => void;
  dailyProgress?: { d: string; n: number; r: number };
  onQuickAddWord?: (w: Partial<Word>) => boolean;
  /** منو به‌جای تمرین نمایش داده شود (جابجایی بین تب‌های اصلی بدون بستن تمرین‌های گرامر) */
  menuMode?: boolean;
  /** کلیک روی یکی از تب‌های اصلی وقتی تمرینی باز است → نمایش منو (تمرین‌های گرامر باز می‌مانند) */
  onEnterMenu?: () => void;
  /** تب فعال VerbPrep (یادگیری/تمرین/افزودن) — وضعیت در App نگه داشته می‌شود تا تمرین باز بماند */
  vprepTab?: 'learn' | 'practice' | 'add';
  onSetVprepTab?: (t: 'learn' | 'practice' | 'add') => void;
}

const ALLOC_KEY = 'wb_flash_new_alloc';
const readAlloc = (d: string): string[] | null => {
  try { const o = JSON.parse(localStorage.getItem(ALLOC_KEY) || 'null'); return o && o.d === d && Array.isArray(o.ids) ? o.ids : null; } catch { return null; }
};
const writeAlloc = (d: string, ids: string[]) => { try { localStorage.setItem(ALLOC_KEY, JSON.stringify({ d, ids })); } catch { /* ignore */ } };

export const ExercisesView: React.FC<ExercisesViewProps> = ({
  words: allWords,
  settings,
  activeMode,
  practiceWordIds,
  onSelectMode,
  onRecordResult,
  onOpenHelp,
  onShowToast,
  onEditWord,
  onDeleteWord,
  onImageChange,
  paused,
  onUpdateSettings,
  onStartHard,
  dailyProgress,
  onQuickAddWord,
  menuMode: menuModeProp,
  onEnterMenu,
  vprepTab: vprepTabProp,
  onSetVprepTab
}) => {
  const topRef = useRef<HTMLDivElement>(null);
  const words = useMemo(() => {
    const cats = settings?.activeCats;
    const exempt = !activeMode || activeMode === 'flash' || activeMode === 'free' || isSelfContainedMode(activeMode);
    if (exempt || !cats || cats.length === 0 || (practiceWordIds && practiceWordIds.length > 0)) return allWords;
    const allowed = new Set(cats);
    return allWords.filter(w => allowed.has(w.cat));
  }, [allWords, settings?.activeCats, activeMode, practiceWordIds]);

  const pausedRef = useRef<boolean>(!!paused);
  pausedRef.current = !!paused;
  const [faShown, setFaShown] = useState(false);
  const [conjPron, setConjPron] = useState(2);

  const [freeCat, setFreeCat] = useState<string>(settings?.freeCat || '');
  const [freeDir, setFreeDir] = useState<'de' | 'fa'>(settings?.freeDir || 'de');
  const [freeRnd, setFreeRnd] = useState<boolean>(settings?.freeRnd ?? true);
  const [isFreeStarted, setIsFreeStarted] = useState<boolean>(false);

  const [flashDir, setFlashDir] = useState<'de' | 'fa' | 'rand'>(settings?.dir || 'de');
  const [flashCat, setFlashCat] = useState<string>('');
  const [isFlashConfigured, setIsFlashConfigured] = useState<boolean>(false);

  const [queue, setQueue] = useState<string[]>([]);
  // صف برای کدام mode ساخته شده — تا هنگام جابه‌جایی تب‌ها کارت کهنهٔ «تبریک» فلش نزند
  const [queueMode, setQueueMode] = useState<ExerciseMode | null>(activeMode);
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  const [revealedCardId, setRevealedCardId] = useState<string | null>(null);
  const [moreOpen, setMoreOpen] = useState(false);

  /** تب گرامر دو سطحی: دستهٔ بازشده در فهرست + تب فعال VerbPrep (سه تمرین جدا) */
  const [gramCat, setGramCat] = useState<number | null>(null);
  /** دستهٔ گرامر انتخاب‌شده در نوار چسبان تمرین (null = دنبال کردن تمرین فعال) */
  const [exCat, setExCat] = useState<number | null>(null);
  // تب فعال VerbPrep در App نگه داشته می‌شود تا با جابجایی تب‌ها تمرین باز بماند
  const vprepTab = vprepTabProp || 'practice';
  const setVprepTab = (t: 'learn' | 'practice' | 'add') => onSetVprepTab?.(t);
  /** نمایش منو به‌جای تمرین: وقتی تمرینی باز نیست یا کاربر از داخل تمرین به تب اصلی رفته است */
  const showMenu = !activeMode || !!menuModeProp;
  const openGramTab = (t: GramTab): void => {
    if (t.vTab) setVprepTab(t.vTab);
    setExCat(null);
    onSelectMode(t.mode);
  };
  const gramSec = activeMode && !showMenu
    ? GRAMMATIK_CATS.find(c => c.tabs.some(t => t.mode === activeMode)) || null
    : (gramCat !== null ? GRAMMATIK_CATS[gramCat] || null : null);
  const activeGramTabId = activeMode && gramSec
    ? gramSec.tabs.find(t => t.mode === activeMode && (t.mode !== 'vprep' || t.vTab === vprepTab))?.id
    : undefined;
  const [currentCardDir, setCurrentCardDir] = useState<'de' | 'fa'>('de');

  const [userInput, setUserInput] = useState<string>('');
  const [casePrepInput, setCasePrepInput] = useState<string>('');
  const [caseArtInput, setCaseArtInput] = useState<string>('');
  const [caseResult, setCaseResult] = useState<{ prepOk: boolean; artOk: boolean } | null>(null);

  const [answerResult, setAnswerResult] = useState<{ ok: number; exp: string; msg?: string; cands?: string[] } | null>(null);
  const [hintLevel, setHintLevel] = useState<number>(0);

  const [profileModalWord, setProfileModalWord] = useState<Word | null>(null);
  const [sentenceModalWord, setSentenceModalWord] = useState<Word | null>(null);
  const [shadowWord, setShadowWord] = useState<Word | null>(null);
  pausedRef.current = !!paused || !!profileModalWord || !!sentenceModalWord;
    
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [timerPopupOpen, setTimerPopupOpen] = useState(false);
  const [timerSecDraft, setTimerSecDraft] = useState<string | null>(null);
  const [sentTimeUp, setSentTimeUp] = useState(0);
  const timeUpRef = useRef<() => void>(() => {});
  const timerRef = useRef<any>(null);

  const [knownMap, setKnownMap] = useState<Record<string, number>>({});
  const categories = useMemo(() => getCategories(words), [words]);

  const hardCountedRef = useRef<Set<string>>(new Set());

  const currentKey = queue[currentIndex] || '';
  const keyParts = currentKey.split('::');
  const currentSub = keyParts[1] || '';
  const currentKind = keyParts[2] || '';
  const qMode: ExerciseMode | null = !activeMode
    ? null
    : activeMode === 'hard'
      ? (currentSub === 'flashDe' || currentSub === 'flashFa' ? 'flash' : ((currentSub as ExerciseMode) || 'flash'))
      : activeMode === 'vmix' || activeMode === 'act'
        ? (currentSub === 'vmc' ? 'vmc' : 'prod')
        : activeMode;
  const hardFlashDir: 'de' | 'fa' | null = activeMode === 'hard'
    ? (currentSub === 'flashFa' ? 'fa' : currentSub === 'flashDe' ? 'de' : null)
    : null;

  const record = (item: Word | CaseQuestion, mode: string, grade: number) => {
    let retry = false;
    if (activeMode === 'hard') {
      retry = hardCountedRef.current.has(item.id);
      hardCountedRef.current.add(item.id);
    }
    onRecordResult(item, mode, grade, retry);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      stopSpeaking();
    };
  }, []);

  useEffect(() => {
    if (!activeMode) {
      setQueue([]);
      setCurrentIndex(0);
      setRevealedCardId(null);
      setUserInput('');
      setCasePrepInput('');
      setCaseArtInput('');
      setCaseResult(null);
      setAnswerResult(null);
      setHintLevel(0);
      setFaShown(false);
      setConjPron(Math.floor(Math.random() * 6));
      setIsFreeStarted(false);
      setIsFlashConfigured(false);
      stopSpeaking();
      return;
    }

    const n = Date.now();
    let qIds: string[] = [];

    let pool = words;
    if (settings?.activeCats && settings.activeCats.length > 0) {
      const allowed = new Set(settings.activeCats);
      pool = pool.filter(w => allowed.has(w.cat));
    }

    if (settings?.leechAct === 'suspend') {
      const leechThreshold = settings.leechN || 4;
      pool = pool.filter(w => !isLeech(w, leechThreshold));
    }

    hardCountedRef.current = new Set();

    if (activeMode === 'hard') {
      const wanted = new Set(
        practiceWordIds && practiceWordIds.length > 0
          ? practiceWordIds
          : words.filter(w => (w.bad || 0) > 3).map(w => w.id)
      );
      qIds = buildHardQueue(words.filter(w => wanted.has(w.id)), settings?.rv || 20);
    } else if (practiceWordIds && practiceWordIds.length > 0) {
      qIds = [...practiceWordIds];
      if (activeMode === 'synant') {
        qIds = words.filter(w => practiceWordIds.includes(w.id)).map(w => synAntKey(w));
      }
      if (activeMode === 'adjdecl') {
        qIds = buildAdjQueue(words.filter(w => practiceWordIds.includes(w.id)), 15);
      }
    } else if (activeMode === 'synant') {
      const synAntPool: Word[] = pool.filter((w: Word) => splitList(w.syn).length > 0 || splitList(w.ant).length > 0);
      qIds = shuffleArr<Word>(synAntPool)
        .slice(0, 15)
        .map((w: Word) => synAntKey(w));
    } else if (activeMode === 'n2v' || activeMode === 'v2n') {
      qIds = shuffleArr<Word>(pool.filter((w: Word) => familyCands(w, activeMode).length > 0))
        .slice(0, 15)
        .map((w: Word) => w.id);
    } else if (activeMode === 'case') {
      qIds = pickCaseQueue();
    } else if (activeMode === 'adjdecl') {
      qIds = buildAdjQueue(pool, 15);
    } else if (activeMode === 'free') {
      return;
    } else if (activeMode === 'flash' || activeMode === 'review') {
      if (!isFlashConfigured && activeMode === 'flash') return;
      if (flashCat) pool = pool.filter(w => w.cat === flashCat);

      if (activeMode === 'review') {
        pool = pool.filter(w => w.last && w.due <= n).sort((a, b) => a.due - b.due);
      } else if (!flashCat) {
        const day = today();
        const dp = dailyProgress && dailyProgress.d ? dailyProgress : { d: '', n: 0, r: 0 };
        const dueSel = pool.filter(w => w.last && w.due <= n).sort((a, b) => a.due - b.due).slice(0, settings?.rv || 20);
        const unseen = pool.filter(w => !w.last);
        const ord = settings?.order || 'due';
        let allocIds = readAlloc(day);
        if (!allocIds) {
          const cand = ord === 'rand' || ord === 'randnew' ? unseen.slice().sort(() => Math.random() - 0.5) : unseen;
          const take = Math.max(0, (settings?.nw ?? 10) - (dp.n || 0));
          allocIds = cand.slice(0, take).map(w => w.id);
          writeAlloc(day, allocIds);
        }
        const allocSet = new Set(allocIds);
        const newSel = unseen.filter(w => allocSet.has(w.id));
        if (ord === 'new') {
          pool = [...newSel, ...dueSel];
        } else if (ord === 'rand') {
          pool = [...dueSel, ...newSel].sort(() => Math.random() - 0.5);
        } else if (ord === 'mix') {
          const mixed: Word[] = [];
          for (let i = 0; i < Math.max(dueSel.length, newSel.length); i++) {
            if (i < dueSel.length) mixed.push(dueSel[i]);
            if (i < newSel.length) mixed.push(newSel[i]);
          }
          pool = mixed;
        } else {
          pool = [...dueSel, ...newSel];
        }
      } else {
        const dueWords = pool.filter(w => w.last && w.due <= n);
        const newWords = pool.filter(w => !w.last);

        const order = settings?.order || 'due';
        if (order === 'new') {
          pool = [...newWords, ...dueWords];
        } else if (order === 'rand') {
          pool = [...dueWords, ...newWords].sort(() => Math.random() - 0.5);
        } else if (order === 'randnew') {
          pool = [...dueWords, ...newWords.slice().sort(() => Math.random() - 0.5)];
        } else if (order === 'mix') {
          const mixed: Word[] = [];
          const maxLen = Math.max(dueWords.length, newWords.length);
          for (let i = 0; i < maxLen; i++) {
            if (i < dueWords.length) mixed.push(dueWords[i]);
            if (i < newWords.length) mixed.push(newWords[i]);
          }
          pool = mixed;
        } else {
          pool = [...dueWords, ...newWords];
        }
      }
      qIds = activeMode === 'flash' && !flashCat ? pool.map(w => w.id) : pool.map(w => w.id).slice(0, settings?.rv || 20);
    } else if (activeMode === 'daily') {
      const due = pool.filter(w => w.last && w.due <= n);
      const nw = pool.filter(w => !w.last);
      const dailyNewLimit = settings?.nw ?? 10;
      const dailyRevLimit = settings?.rv ?? 20;
      qIds = [...due.slice(0, dailyRevLimit), ...nw.slice(0, dailyNewLimit)].map(w => w.id);
    } else if (activeMode === 'vmix') {
      // فاز ۲: صف دوگانه — فعال/کاندید: تولید (تایپ معادل)؛ دریافتی: انتخاب معنی (vmc)؛ درهم‌بافته
      const akt = pool.filter(w => statusOf(w) !== 'passiv').sort(() => Math.random() - 0.5).slice(0, 10);
      const pas = pool.filter(w => statusOf(w) === 'passiv').sort(() => Math.random() - 0.5).slice(0, 10);
      const mixed: string[] = [];
      for (let i = 0; i < Math.max(akt.length, pas.length); i++) {
        if (akt[i]) mixed.push(`${akt[i].id}::prod::`);
        if (pas[i]) mixed.push(`${pas[i].id}::vmc::`);
      }
      qIds = mixed.sort(() => Math.random() - 0.5);
    } else if (activeMode === 'act') {
      // فاز ۳: صف فعال‌سازی — فقط واژه‌های کاندید؛ تمرین تولیدی (معنی → تایپ معادل آلمانی)؛ کهنه‌ترین اول
      const kands = pool.filter(w => statusOf(w) === 'kandidat').sort((a, b) => (a.last || 0) - (b.last || 0));
      qIds = kands.map(w => `${w.id}::prod::`);
    } else if (activeMode === 'art') {
      qIds = pool.filter(w => !!w.art).sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'cloze') {
      qIds = pool.filter(w => !!w.cloze || !!w.ans).sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'plural') {
      qIds = pool.filter(w => !!w.pl).sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'conj') {
      qIds = pool.filter(w => !!w.conj).sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'tense') {
      qIds = pool.filter(w => !!w.prat || !!w.perf).sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'dict' || activeMode === 'prod') {
      qIds = pool.slice().sort(() => Math.random() - 0.5).slice(0, 15).map(w => w.id);
    } else if (activeMode === 'sent') {
      qIds = shuffleArr<Word>(pool).slice(0, 10).map(w => w.id);
    } else if (activeMode === 'konnektoren') {
      qIds = ['konnektoren-main'];
    } else if (isSelfContainedMode(activeMode)) {
      qIds = ['freesent-self'];
    }
    setQueue(qIds);
    setQueueMode(activeMode);
    setCurrentIndex(0);
    setRevealedCardId(null);
    setUserInput('');
    setCasePrepInput('');
    setCaseArtInput('');
    setCaseResult(null);
    setAnswerResult(null);
    setHintLevel(0);
    setFaShown(false);
    setConjPron(Math.floor(Math.random() * 6));
  }, [activeMode, practiceWordIds, isFlashConfigured, flashCat, settings?.order, settings?.activeCats, settings?.leechAct]);

  const currentItem = useMemo(() => {
    if (queue.length === 0 || currentIndex >= queue.length) return null;
    const id = queue[currentIndex].split('::')[0];
    if (activeMode === 'case') {
      return ALL_CASEQ.find(q => q.id === id) || null;
    }
    if (activeMode === 'konnektoren') {
      return FREE_SENT_WORD;
    }
    if (isSelfContainedMode(activeMode)) {
      return FREE_SENT_WORD;
    }
    return words.find(w => w.id === id) || null;
  }, [queue, currentIndex, activeMode, words]);
        
  const cardKeyNow = queue[currentIndex] || '';
  useEffect(() => { setMoreOpen(false); }, [cardKeyNow]);
  useEffect(() => {
    const flashLike = activeMode === 'flash' || activeMode === 'free' || activeMode === 'review' || activeMode === 'daily';
    if (!flashLike || !currentItem || moreOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [activeMode, currentItem, moreOpen]);

  const adjInfo = useMemo(() => {
    if (qMode !== 'adjdecl' || !currentItem) return null;
    const w = currentItem as Word;
    const [code, specStr] = (currentKind || '').split('~');
    const src = adjSourceByCode(w, code);
    const spec = parseSpec(specStr);
    if (!src || !spec) return null;
    const item = buildAdjItem(src.base, spec);
    return item ? { item, src } : null;
  }, [qMode, currentItem, currentKind]);

  useEffect(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    stopSpeaking();

    if (!currentItem) return;

    const defaultDir = settings?.dir || 'de';
    if (hardFlashDir) {
      setCurrentCardDir(hardFlashDir);
    } else if (activeMode === 'free') {
      setCurrentCardDir(freeRnd ? (Math.random() > 0.5 ? 'de' : 'fa') : freeDir);
    } else if (defaultDir === 'rand') {
      setCurrentCardDir(Math.random() > 0.5 ? 'de' : 'fa');
    } else if (activeMode === 'flash') {
      setCurrentCardDir(flashDir === 'rand' ? (Math.random() > 0.5 ? 'de' : 'fa') : flashDir);
    } else {
      setCurrentCardDir(defaultDir);
    }

    setRevealedCardId(null);

    const isFlashType = qMode === 'flash' || qMode === 'free' || qMode === 'review';

    if (isFlashType && settings?.auto && currentCardDir === 'de' && revealedCardId !== currentItem.id) {
      const w = currentItem as Word;
      speak(fullWord(w), {
        rate: settings.rate,
        vreg: settings.vreg,
        voiceName: settings.voice
      });
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      stopSpeaking();
    };
  }, [currentIndex, currentItem?.id, currentKey, qMode, activeMode, freeDir, freeRnd, flashDir, settings?.dir]);

  const timerCfg: ExerciseTimerCfg = qMode ? getTimerCfg(settings, qMode) : { on: false, sec: 30 };
  const timerAnswered = !!answerResult || !!caseResult || (!!currentItem && revealedCardId === currentItem.id);
  const hasItem = !!currentItem;
  useEffect(() => {
    if (!activeMode || !hasItem || !timerCfg.on || timerCfg.sec <= 0 || timerAnswered) {
      setTimeLeft(null);
      return;
    }
    let left = timerCfg.sec;
    setTimeLeft(left);
    const id = setInterval(() => {
      if (pausedRef.current) return;
      left -= 1;
      setTimeLeft(left);
      if (left <= 0) {
        clearInterval(id);
        timeUpRef.current();
      }
    }, 1000);
    return () => clearInterval(id);
  }, [activeMode, currentKey, currentIndex, qMode, hasItem, timerCfg.on, timerCfg.sec, timerAnswered]);

  useEffect(() => {
    if (profileModalWord && activeMode !== 'case' && !ALL_CASEQ.some(q => q.id === profileModalWord.id)) {
      if (!words.some(w => w.id === profileModalWord.id)) setProfileModalWord(null);
    }
    if (!activeMode || activeMode === 'case' || queue.length === 0) return;
    const exists = new Set(words.map(w => w.id));
    const keep = queue.map(k => exists.has(k.split('::')[0]));
    if (keep.every(Boolean)) return;
    const removedBefore = keep.slice(0, currentIndex).filter(x => !x).length;
    const currentRemoved = currentIndex < keep.length && !keep[currentIndex];
    setQueue(queue.filter((_, i) => keep[i]));
    setCurrentIndex(Math.max(0, currentIndex - removedBefore));
    if (currentRemoved) {
      setRevealedCardId(null);
      setUserInput('');
      setCasePrepInput('');
      setCaseArtInput('');
      setCaseResult(null);
      setAnswerResult(null);
      setHintLevel(0);
      setFaShown(false);
      setConjPron(Math.floor(Math.random() * 6));
    }
  }, [words]);

  const advanceQuestion = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    stopSpeaking();
    setCurrentIndex(prev => prev + 1);
    setRevealedCardId(null);
    setUserInput('');
    setCasePrepInput('');
    setCaseArtInput('');
    setCaseResult(null);
    setAnswerResult(null);
    setHintLevel(0);
    setFaShown(false);
    setConjPron(Math.floor(Math.random() * 6));
    setMoreOpen(false);
    if (topRef.current) {
      topRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleFlashGrade = (grade: number) => {
    if (!currentItem) return;
    record(currentItem, qMode || 'flash', grade);
    if (grade === 0) {
      setQueue(prev => [...prev, currentKey]);
    }
    advanceQuestion();
  };

  const handleFreeKnow = (know: number) => {
    if (!currentItem) return;
    setKnownMap(prev => ({ ...prev, [currentItem.id]: know }));
    advanceQuestion();
  };

  const handleRevealCard = () => {
    if (!currentItem) return;
    setRevealedCardId(currentItem.id);
    if (timerRef.current) clearInterval(timerRef.current);

    const w = currentItem as Word;
    if ((settings?.auto || settings?.autoEx) && currentCardDir === 'de') {
      stopSpeaking();
      speak(fullWord(w), {
        rate: settings?.rate,
        vreg: settings?.vreg,
        voiceName: settings?.voice,
        onEnd: () => {
          if (settings?.autoEx && w.ex) {
            speak(w.ex, {
              rate: settings.rate,
              vreg: settings.vreg,
              voiceName: settings.voice
            });
          }
        }
      });
    }
  };

  const runCaseCheck = (force: boolean) => {
    if (!currentItem || answerResult) return;
    const q = currentItem as CaseQuestion;

    const prep = casePrepInput.trim().toLowerCase();
    const art = caseArtInput.trim().toLowerCase();

    if (!prep && !art && !force) {
      onShowToast('لطفاً هر دو جای خالی را پر کنید.', true);
      return;
    }

    const prepExpected = q.prepAns.toLowerCase();
    const artExpected = q.artAns.toLowerCase();

    const isPrepOk = prep === prepExpected;
    const isArtOk = art === artExpected;

    setCaseResult({ prepOk: isPrepOk, artOk: isArtOk });

    let msg = '';
    const isBothOk = isPrepOk && isArtOk;

    if (isBothOk) {
      msg = `✔ آفرین! هر دو بخش درست است. (${q.prepAns} ${q.artAns})`;
    } else if (!isPrepOk && isArtOk) {
      msg = `❌ حرف اضافه نادرست است (درست: «${q.prepAns}») • آرتیکل درست بود («${q.artAns}»)`;
    } else if (isPrepOk && !isArtOk) {
      msg = `✔ حرف اضافه درست است («${q.prepAns}») • ❌ آرتیکل نادرست است (درست: «${q.artAns}»)`;
    } else {
      msg = `❌ هر دو نادرست است (حرف اضافه درست: «${q.prepAns}» • آرتیکل درست: «${q.artAns}»)`;
    }

    setAnswerResult({
      ok: isBothOk ? 1 : 0,
      exp: `${q.prepAns} ${q.artAns}`,
      msg
    });

    record(q, 'case', isBothOk ? 2 : (isPrepOk || isArtOk ? 1 : 0));
    if (!isBothOk) {
      setQueue(prev => [...prev, currentKey]);
    }
  };

  const runCheckAnswer = (force: boolean) => {
    if (!currentItem || answerResult) return;
    const trimmed = userInput.trim();
    if (!trimmed && !force) {
      onShowToast('لطفاً پاسخ را وارد کنید.', true);
      return;
    }

    const w = currentItem as Word;

    if (qMode === 'conj') {
      const chk = checkConjAnswer(w.conj, conjPron, trimmed, w.de);
      const res = {
        ok: chk.ok ? 1 : 0,
        exp: chk.target,
        msg: chk.ok
          ? undefined
          : chk.wrongPron
            ? `ضمیر «${chk.wrongPron}» با سؤال نمی‌خواند؛ سؤال برای «${P6[conjPron]}» است. شکل درست: ${chk.target}`
            : chk.missingPart
              ? `فعل جداشدنی کامل نیست؛ جزء «${chk.target.split(/\s+/).slice(1).join(' ')}» هم لازم است. شکل درست: ${chk.target}`
              : chk.otherIdx >= 0
                ? `این شکل مربوط به «${P6[chk.otherIdx]}» است؛ سؤال برای «${P6[conjPron]}» است. شکل درست: ${chk.target}`
                : `شکل درست برای «${P6[conjPron]}»: ${chk.target}`,
        cands: chk.cands
      };
      setAnswerResult(res);
      record(w, 'conj', chk.ok ? (faShown ? 1 : 2) : 0);
      return;
    }

    if (qMode === 'tense') {
      const expPrat = w.prat || '';
      const expPerf = w.perf || '';
      const isCorrect =
        trimmed.toLowerCase() === expPrat.toLowerCase() ||
        trimmed.toLowerCase() === expPerf.toLowerCase() ||
        trimmed.toLowerCase() === `er ${expPrat}`.toLowerCase();
      const res = {
        ok: isCorrect ? 1 : 0,
        exp: expPrat || expPerf,
        msg: isCorrect ? undefined : `شکل‌های درست: Prät: ${w.prat} • Perf: ${w.perf}`,
        cands: [expPrat, expPerf, expPrat ? `er ${expPrat}` : ''].filter(Boolean)
      };
      setAnswerResult(res);
      record(w, 'tense', isCorrect ? (faShown ? 1 : 2) : 0);
      return;
    }

    if (qMode === 'plural') {
      const base = (w.pl || '').trim().replace(/^die\s+/i, '');
      const cands = [base, `die ${base}`];
      const isCorrect = cands.some(c => nz(c) === nz(trimmed));
      setAnswerResult({
        ok: isCorrect ? 1 : 0,
        exp: base,
        msg: isCorrect ? undefined : `شکل جمع درست: ${base}`,
        cands
      });
      record(w, 'plural', isCorrect ? (hintLevel > 0 || faShown ? 1 : 2) : 0);
      if (!isCorrect) setQueue(prev => [...prev, currentKey]);
      return;
    }

    if (qMode === 'adjdecl') {
      if (!adjInfo) return;
      const { item } = adjInfo;
      const clean = nz2(trimmed);
      const isCorrect = clean === nz2(item.answer);
      let msg: string | undefined;
      if (!isCorrect) {
        if (clean === nz2(item.base)) {
          msg = `شکل پایه را نوشته‌اید؛ در این جمله صفت پایانه می‌گیرد: ${item.answer}`;
        } else if (/\s/.test(trimmed)) {
          msg = `فقط خودِ صفت را بنویسید (آرتیکل و اسم در جمله آمده‌اند): ${item.answer}`;
        } else {
          msg = `شکل درست صفت: ${item.answer}  (پایانهٔ «-${item.ending}»)`;
        }
      }
      setAnswerResult({ ok: isCorrect ? 1 : 0, exp: item.answer, msg, cands: [item.answer] });
      record(w, 'adjdecl', isCorrect ? (hintLevel > 0 || faShown ? 1 : 2) : 0);
      if (!isCorrect) setQueue(prev => [...prev, currentKey]);
      return;
    }

    if (qMode === 'synant') {
      const isAnt = currentKind === 'ant';
      const cands = splitList(isAnt ? w.ant : w.syn);
      const sa = checkSynAnt(cands, trimmed, c => words.find(x => nz(x.de) === nz(c) && !!x.art)?.art || '');
      const isCorrect = sa.ok;
      setAnswerResult({
        ok: isCorrect ? 1 : 0,
        exp: cands[0] || '',
        msg: isCorrect ? undefined : (sa.msg ? `${sa.msg} — ${isAnt ? 'متضاد' : 'مترادف'}ها: ${cands.join('، ')}` : `${isAnt ? 'متضاد' : 'مترادف'} درست: ${cands.join('، ')}`),
        cands
      });
      record(w, 'synant', isCorrect ? (hintLevel > 0 || faShown ? 1 : 2) : 0);
      if (!isCorrect) setQueue(prev => [...prev, currentKey]);
      return;
    }

    if (qMode === 'n2v' || qMode === 'v2n') {
      const cands = familyCands(w, qMode);
      const noSich = (x: string) => nz(x.replace(/^sich\s+/i, ''));
      const isCorrect = qMode === 'n2v'
        ? cands.some(c => noSich(c) === noSich(trimmed))
        : cands.some(c => nz(c) === nz(trimmed));
      let msg: string | undefined;
      if (!isCorrect) {
        const bare = cands.find(c => nz(c.replace(/^(der|die|das)\s+/i, '')) === nz(trimmed));
        msg = qMode === 'v2n' && bare
          ? `آرتیکل را ننوشتید؛ پاسخ درست: ${bare}`
          : `${qMode === 'n2v' ? 'فعل' : 'اسم'} هم‌خانوادهٔ درست: ${cands.join('، ')}`;
      }
      setAnswerResult({ ok: isCorrect ? 1 : 0, exp: cands[0] || '', msg, cands });
      record(w, qMode, isCorrect ? (hintLevel > 0 || faShown ? 1 : 2) : 0);
      if (!isCorrect) setQueue(prev => [...prev, currentKey]);
      return;
    }

    const r = checkWord(w, trimmed, qMode || 'cloze');
    setAnswerResult({ ok: r.ok, exp: r.exp, msg: r.msg, cands: r.cands && r.cands.length ? r.cands : [r.exp, ...(w.acc || [])] });
    record(w, qMode || 'cloze', r.ok ? (hintLevel > 0 || faShown ? 1 : 2) : 0);
    if (!r.ok) {
      setQueue(prev => [...prev, currentKey]);
    }
  };

  const handleCheckCaseAnswer = () => runCaseCheck(false);
  const handleCheckAnswer = () => runCheckAnswer(false);

  const answerArt = (art: string) => {
    if (!currentItem || answerResult) return;
    const w = currentItem as Word;
    const ok = !!art && w.art.toLowerCase() === art;
    setAnswerResult({
      ok: ok ? 1 : 0,
      exp: `${w.art} ${w.de}`,
      msg: ok ? undefined : `آرتیکل درست: ${w.art}`
    });
    record(w, 'art', ok ? (faShown ? 1 : 2) : 0);
  };

  timeUpRef.current = () => {
    if (!currentItem) return;
    if (qMode === 'flash' || qMode === 'free' || qMode === 'review' || qMode === 'daily') {
      setRevealedCardId(currentItem.id);
    } else if (qMode === 'sent') {
      setSentTimeUp(n => n + 1);
    } else if (isSelfContainedMode(qMode)) {
      // free practice
    } else if (qMode === 'art') {
      answerArt('');
    } else if (qMode === 'case') {
      runCaseCheck(true);
    } else {
      runCheckAnswer(true);
    }
  };

  const handleOpenWordProfile = () => {
    if (!currentItem) return;
    if (qMode === 'adjdecl' && adjInfo) {
      const base = String(adjInfo.item.base || adjInfo.src.base || '').trim().toLowerCase();
      if (base) {
        const matched = words.find(w => nz(w.de) === nz(base));
        if (matched) { setProfileModalWord(matched); return; }
        setProfileModalWord({
          id: `adj-${base}`,
          de: base,
          art: '',
          fa: adjInfo.src.fa || '',
          pos: 'صفت',
          lvl: (currentItem as Word).lvl || 'A2',
          cat: (currentItem as Word).cat || 'گرامر',
          ex: '', exFa: '', ex2: '', ex2Fa: '',
          notes: '',
          syn: '', synFa: '', ant: '', antFa: '', pl: '', conj: '', prat: '', perf: '', sep: '',
          cloze: '', ans: '', acc: [], tags: '', img: '',
          added: Date.now(), last: 0, due: 0, ivl: 0, ease: 2.5, stage: 0, ok: 0, bad: 0, res: ''
        } as Word);
        return;
      }
    }
    if (qMode === 'case') {
      const q = currentItem as CaseQuestion;
      const cleanNoun = q.n.replace(/^(der|die|das)\s+/i, '').trim();
      const matched = words.find(w => w.de.toLowerCase() === cleanNoun.toLowerCase());
      if (matched) {
        setProfileModalWord(matched);
      } else {
        setProfileModalWord({
          id: q.id,
          de: cleanNoun,
          art: (q.n.match(/^(der|die|das)/i) || [''])[0].toLowerCase(),
          fa: q.fa,
          ex: q.ex,
          exFa: q.exFa,
          ex2: '',
          ex2Fa: '',
          notes: `${q.r}\nحالت دستوری: ${q.c}`,
          pos: 'اسم',
          lvl: 'A1',
          cat: 'گرامر و حالت‌ها',
          added: Date.now(),
          last: 0,
          due: 0,
          ivl: 0,
          ease: 2.5,
          stage: 0,
          ok: 0,
          bad: 0,
          res: '',
          syn: '',
          synFa: '',
          ant: '',
          antFa: '',
          pl: '',
          conj: '',
          prat: '',
          perf: '',
          sep: '',
          cloze: '',
          ans: '',
          acc: [],
          tags: '',
          img: ''
        });
      }
    } else {
      setProfileModalWord(currentItem as Word);
    }
  };

  const renderUnifiedWordCard = (w: Word, opts?: { hideConj?: boolean }) => {
    return (
      <div className="bg-white dark:bg-[#141923] border border-slate-200 dark:border-slate-800 rounded-3xl p-4 md:p-5 space-y-4 text-right shadow-sm">
        {/* هدر مشابه پروفایل واژه */}
        <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-l from-slate-100 to-indigo-50/50 dark:from-slate-800 dark:to-indigo-950/30 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-800">
          <div className="flex items-center gap-1.5 flex-wrap">
            {w.lvl && <span className="px-2.5 py-0.5 rounded-lg font-bold text-xs bg-amber-400 text-amber-950 shadow-xs">{w.lvl}</span>}
            {w.pos && <span className="px-2.5 py-0.5 rounded-lg font-bold text-xs bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 shadow-xs">{w.pos}</span>}
            {w.cat && <span className="px-2.5 py-0.5 rounded-lg font-bold text-xs bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 shadow-xs">{w.cat}</span>}
          </div>
        </div>

        {/* واژه آلمانی و فارسی */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 dark:bg-[#1b2029] p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2" dir="ltr">
            {w.art && (
              <span className={`px-2.5 py-1 rounded-xl font-bold text-base ${
                w.art === 'der' ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300' :
                w.art === 'die' ? 'bg-pink-100 text-pink-800 dark:bg-pink-950 dark:text-pink-300' :
                'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
              }`}>
                {w.art}
              </span>
            )}
            <span className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-sans">
              {w.de}
            </span>
            <button
              onClick={() => speak(fullWord(w), { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })}
              className="w-9 h-9 rounded-full bg-white dark:bg-slate-800 text-sm flex items-center justify-center shadow-xs hover:scale-105 transition"
              title="تلفظ"
            >
              🔊
            </button>
          </div>

          <div className="text-xl md:text-2xl font-extrabold text-[#1f5fbf] dark:text-[#7fb0ff]">
            {w.fa}
          </div>
        </div>

        {/* معادل انگلیسی */}
        {w.en && (
          <div className="flex items-baseline gap-2 py-2.5 px-3.5 rounded-2xl border bg-blue-50/50 dark:bg-blue-950/20 border-blue-200/80 dark:border-blue-900 text-blue-900 dark:text-blue-200">
            <span className="text-sm font-extrabold w-28 flex-shrink-0">معادل انگلیسی 🇬🇧</span>
            <span className="flex-1 min-w-0 text-base font-sans font-bold" dir="ltr">{w.en}</span>
          </div>
        )}

        {/* مترادف و متضاد با ترجمه در دو خط جداگانه */}
        {(w.syn || w.ant) && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {w.syn && (
              <div className="flex flex-col gap-1 p-3 rounded-2xl border bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-900 text-emerald-900 dark:text-emerald-200">
                <span className="text-xs font-extrabold text-emerald-700 dark:text-emerald-300">مترادف (Synonym)</span>
                <span className="font-bold text-base" dir="ltr">{w.syn}</span>
                {w.synFa && <span className="text-sm text-slate-600 dark:text-slate-400 font-medium">{w.synFa}</span>}
              </div>
            )}
            {w.ant && (
              <div className="flex flex-col gap-1 p-3 rounded-2xl border bg-rose-50/50 dark:bg-rose-950/20 border-rose-200/80 dark:border-rose-900 text-rose-900 dark:text-rose-200">
                <span className="text-xs font-extrabold text-rose-700 dark:text-rose-300">متضاد (Antonym)</span>
                <span className="font-bold text-base" dir="ltr">{w.ant}</span>
                {w.antFa && <span className="text-sm text-slate-600 dark:text-slate-400 font-medium">{w.antFa}</span>}
              </div>
            )}
          </div>
        )}

        {/* جمع اسم (Plural) */}
        {w.pl && (
          <div className="flex items-baseline gap-2 py-2.5 px-3.5 rounded-2xl border bg-purple-50/50 dark:bg-purple-950/20 border-purple-200/80 dark:border-purple-900 text-purple-900 dark:text-purple-200">
            <span className="text-sm font-extrabold w-28 flex-shrink-0">شکل جمع (Plural)</span>
            <span className="flex-1 min-w-0 text-base font-sans font-bold" dir="ltr">{w.pl}</span>
          </div>
        )}

        {/* تعریف آلمانی */}
        {w.def && (
          <div className="bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900 p-3.5 rounded-2xl text-base" dir="ltr">
            <span className="text-xs font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wide block mb-1">Bedeutung & Definition</span>
            <span className="font-sans font-semibold text-slate-800 dark:text-slate-100">{w.def}</span>
          </div>
        )}

        {/* مثال‌های کاربردی */}
        {(w.ex || w.ex2) && (
          <div className="space-y-2.5">
            <div className="text-sm font-extrabold text-slate-700 dark:text-slate-300 px-1">📝 مثال‌های کاربردی (Praxisbeispiele)</div>
            {w.ex && (
              <div className="bg-slate-50 dark:bg-[#1b2029] p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2" dir="ltr">
                  <p className="text-base font-semibold text-slate-900 dark:text-slate-100 text-left">
                    {w.ex}
                  </p>
                  <button onClick={() => speak(w.ex, { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })} className="text-base">🔊</button>
                </div>
                {w.exFa && (
                  <p className="text-sm text-slate-600 dark:text-slate-300 text-right font-medium" dir="rtl">
                    {w.exFa}
                  </p>
                )}
              </div>
            )}
            {w.ex2 && (
              <div className="bg-slate-50 dark:bg-[#1b2029] p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between gap-2" dir="ltr">
                  <p className="text-base font-semibold text-slate-900 dark:text-slate-100 text-left">
                    {w.ex2}
                  </p>
                  <button onClick={() => speak(w.ex2, { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })} className="text-base">🔊</button>
                </div>
                {w.ex2Fa && (
                  <p className="text-sm text-slate-600 dark:text-slate-300 text-right font-medium" dir="rtl">
                    {w.ex2Fa}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {/* جدول صرف فعل */}
        {w.conj && !opts?.hideConj && (
          (() => {
            const forms = splitConj(w.conj);
            const [colL, colR] = splitConjColumns(forms);
            const renderCol = (col: string[], offset: number) => (
              <div className="flex-1 min-w-[140px] space-y-1.5">
                {col.map((f, i) => (
                  <div key={offset + i} className="flex items-baseline justify-between gap-2 py-1 border-b border-slate-100 dark:border-slate-800/60 last:border-0" dir="ltr">
                    <span className="text-sm font-bold text-slate-400 flex-shrink-0">{P6[offset + i]}</span>
                    <span className="min-w-0 text-right">
                      <HighlightedVerbForm verb={w.de} form={f} pronounIndex={offset + i} sep={w.sep} />
                    </span>
                  </div>
                ))}
              </div>
            );
            return (
              <div className="space-y-2">
                <div className="text-sm font-extrabold text-slate-700 dark:text-slate-300 px-1">🔄 جدول صرف فعل (Konjugation)</div>
                <div className="text-base bg-slate-50 dark:bg-[#1b2029] p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <div className="flex flex-col sm:flex-row gap-4" dir="ltr">
                    {renderCol(colL, 0)}
                    <div className="hidden sm:block w-px bg-slate-200 dark:bg-slate-800 self-stretch" />
                    {renderCol(colR, 3)}
                  </div>
                </div>
              </div>
            );
          })()
        )}

        {/* زمان‌های گذشته */}
        {(w.prat || w.perf) && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2" dir="ltr">
            {w.prat && (
              <div className="rounded-2xl p-3 border bg-amber-50/50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900">
                <div className="text-xs font-bold opacity-75 mb-0.5 text-amber-900 dark:text-amber-200">Präteritum (گذشته ساده)</div>
                {/* فاز ۴ #۵: فونت خنثی تا هایلایت قرمز پایانه‌ها دیده شود */}
                <div className="text-base font-bold text-slate-800 dark:text-slate-100"><PratText inf={w.de} prat={w.prat} /></div>
              </div>
            )}
            {w.perf && (
              <div className="rounded-2xl p-3 border bg-sky-50/50 border-sky-200 text-sky-900 dark:bg-sky-950/20 dark:border-sky-900 dark:text-sky-100">
                <div className="text-xs font-bold opacity-75 mb-0.5">Perfekt (گذشته نقلی)</div>
                <div className="text-base font-bold font-sans">{w.perf}</div>
              </div>
            )}
          </div>
        )}
        
        {w.img && (
          <div className="text-center pt-2">
            <img src={w.img} alt={w.de} className="max-h-48 mx-auto rounded-2xl object-contain shadow-xs border border-slate-200 dark:border-slate-800" />
          </div>
        )}
      </div>
    );
  };
        
  const [mainTab, setMainTab] = useState<MainTab>(() => (sessionStorage.getItem('wb_main_tab') as MainTab) || 'flash');
  useEffect(() => { try { sessionStorage.setItem('wb_main_tab', mainTab); } catch { /* ignore */ } }, [mainTab]);
  const [showHard, setShowHard] = useState(false);
  /** پنجرهٔ «تولید جملهٔ آزاد» در تمرین جای‌خالی فعل+حرف اضافه (کنار آیکن راهنما) */
  const [freeOpen, setFreeOpen] = useState(false);

  /**
   * کلیک روی تب اصلی: در حالت منو فقط تب عوض می‌شود؛ اما وقتی تمرینی باز است
   * به منو برمی‌گردیم بدون بستن تمرین (تمرین‌های گرامر در App باز می‌مانند).
   */
  const handleMainTab = (id: MainTab) => {
    setMainTab(id);
    if (!showMenu) onEnterMenu?.();
  };

  // ⚠️ همهٔ hookها باید بالاتر از این خط باشند؛ از اینجا به بعد return زودهنگام داریم.
  /** نوار چسبان: تب‌های اصلی + (اختیاری) نوار زیرتب‌های گرامر — همیشه هنگام اسکرول ثابت می‌ماند */
  const renderTabHeader = (extras?: React.ReactNode) => (
    <div className="sticky top-16 md:top-[4.5rem] z-20 bg-[#f6f7fb] dark:bg-[#12151c] -mx-2 px-2 py-2 space-y-1.5">
      <div className="flex gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden p-1.5 bg-slate-100 dark:bg-[#141923] rounded-2xl border border-[#dde1ea] dark:border-[#333b4a] text-xs sm:text-sm font-bold shadow-xs">
        {MAIN_TABS.map(t => (
          <button
            key={t.id}
            onClick={() => handleMainTab(t.id)}
            className={`flex-1 min-w-[68px] shrink-0 py-2.5 px-1 rounded-xl transition flex flex-col items-center gap-1 ${mainTab === t.id ? 'bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white shadow-md' : 'text-slate-700 dark:text-slate-300'}`}
          >
            <span className="text-base leading-none">{t.icon}</span>
            <span className="text-[11px] leading-tight whitespace-nowrap">{t.label}</span>
          </button>
        ))}
      </div>
      {extras}
    </div>
  );

  /** زیرتب‌های گرامر برای نوار چسبان: ردیف دسته‌ها + ردیف تب‌های دستهٔ نمایش‌داده‌شده */
  const gramStickyBars = (mainTab === 'grammatik' && !showMenu) ? (() => {
    const curIdx = gramSec ? GRAMMATIK_CATS.indexOf(gramSec) : (gramCat ?? 0);
    const shown = GRAMMATIK_CATS[exCat !== null ? exCat : curIdx] || gramSec || GRAMMATIK_CATS[0];
    return (
      <div className="space-y-1.5">
        <div className="flex gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden p-1 bg-slate-100 dark:bg-[#141923] rounded-xl border border-[#dde1ea] dark:border-[#333b4a]">
          {GRAMMATIK_CATS.map((c, i) => (
            <button
              key={c.label}
              onClick={() => setExCat(i)}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition flex-shrink-0 ${(exCat !== null ? exCat : curIdx) === i ? 'bg-[#6b4fd8] text-white shadow-xs' : 'text-[#5d6676] dark:text-[#a3adbd]'}`}
            >
              {c.icon} {c.label}
            </button>
          ))}
        </div>
        <div className="flex gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden p-1 bg-white dark:bg-[#1b2029] rounded-xl border border-[#dde1ea] dark:border-[#333b4a]">
          {shown.tabs.map(t => (
            <button
              key={t.id}
              onClick={() => openGramTab(t)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition flex-shrink-0 ${t.id === activeGramTabId ? 'bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-[#5d6676] dark:text-[#a3adbd]'}`}
            >{t.label}</button>
          ))}
        </div>
      </div>
    );
  })() : undefined;

  // تب‌های مستقل (کامپوننت خودشان همهٔ UI را دارند و از مسیر activeMode نمی‌گذرند)
  if (showMenu && mainTab === 'sprechen') {
    return (
      <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10">
        {renderTabHeader()}
        <SprechenTrainer onClose={() => setMainTab('flash')} onShowToast={onShowToast} />
      </div>
    );
  }

  if (showMenu && mainTab === 'lesen') {
    return (
      <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10">
        {renderTabHeader()}
        <LesenTrainer onClose={() => setMainTab('flash')} onShowToast={onShowToast} onQuickAddWord={onQuickAddWord} />
      </div>
    );
  }

  if (showMenu && mainTab === 'hoeren') {
    return (
      <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10">
        {renderTabHeader()}
        {/* هر تمرین Hören در صفحهٔ جدا باز می‌شود (از مسیر activeMode) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {HOEREN_MODES.map(mode => {
            const info = EXERCISE_NAMES[mode];
            return (
              <button
                key={mode}
                onClick={() => onSelectMode(mode)}
                className="p-3 rounded-xl bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] hover:border-[#1f5fbf] text-right transition flex items-center gap-2.5 shadow-xs"
              >
                <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">{info.icon}</span>
                <div className="min-w-0">
                  <div className="text-[13px] font-bold leading-snug">{info.title}</div>
                  <div className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] mt-0.5">{info.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  if (showMenu) {
    const activeCatCount = settings?.activeCats?.length || 0;
    const hardWordsCount = allWords.filter(w => (w.bad || 0) > 3).length;

    return (
      <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10">
        {renderTabHeader()}

        {mainTab === 'flash' && (
          <div className="space-y-3">
            <button
              onClick={() => onSelectMode('flash')}
              className="w-full text-right rounded-2xl p-4 bg-gradient-to-br from-[#1f5fbf] via-[#4a5ac9] to-[#6b4fd8] text-white shadow-xl active:scale-[.99] transition relative overflow-hidden"
            >
              <div className="relative flex items-center gap-3 w-full">
                <span className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center text-3xl flex-shrink-0">🃏</span>
                <div className="min-w-0 flex-1">
                  <div className="text-lg font-extrabold">جعبه لایتنر و فلش‌کارت</div>
                  <div className="text-xs text-white/85 mt-1">مرور هوشمند واژگان با تکرار فاصله‌دار استاندارد</div>
                  <div className="text-[11px] text-white/85 mt-2.5 flex flex-wrap gap-1.5">
                    <span className="bg-white/15 rounded-full px-2.5 py-0.5">📚 {words.length} واژه آماده مرور</span>
                    {activeCatCount > 0 && <span className="bg-white/15 rounded-full px-2.5 py-0.5">🗂 {activeCatCount} دستهٔ فعال</span>}
                  </div>
                </div>
                <span className="text-xl text-white/85">‹</span>
              </div>
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => onSelectMode('review')}
                className="p-3 rounded-xl bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] hover:border-[#1f5fbf] text-right transition flex items-center gap-2.5 shadow-xs"
              >
                <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">🔁</span>
                <div>
                  <div className="text-[13px] font-bold leading-snug">مرور سررسیدها</div>
                  <div className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] mt-0.5">فقط واژه‌های نیازمند مرور امروز</div>
                </div>
              </button>
              <button
                onClick={() => onSelectMode('daily')}
                className="p-3 rounded-xl bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] hover:border-[#1f5fbf] text-right transition flex items-center gap-2.5 shadow-xs"
              >
                <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">🌟</span>
                <div>
                  <div className="text-[13px] font-bold leading-snug">جلسه روزانه</div>
                  <div className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] mt-0.5">ترکیب سررسیدها + لغات جدید</div>
                </div>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <button
                onClick={() => onSelectMode('free')}
                className="p-3 rounded-xl bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] hover:border-[#1f5fbf] text-right transition flex items-center gap-2.5 shadow-xs"
              >
                <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">📚</span>
                <div>
                  <div className="text-[13px] font-bold leading-snug">مرور آزاد دسته</div>
                  <div className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] mt-0.5">مرور کل یک دسته بدون اثر بر لایتنر</div>
                </div>
              </button>
              <button
                onClick={() => setShowHard(true)}
                className="p-3 rounded-xl bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] hover:border-[#1f5fbf] text-right transition flex items-center gap-2.5 shadow-xs"
              >
                <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">🩸</span>
                <div>
                  <div className="text-[13px] font-bold leading-snug">واژه‌های پر اشتباه ({hardWordsCount})</div>
                  <div className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] mt-0.5">تمرین اختصاصی واژه‌های سخت</div>
                </div>
              </button>
            </div>
          </div>
        )}

        {mainTab === 'wortschatz' && (
          <div className="space-y-3">
            {WORTSCHATZ_MODES.filter(m => m !== 'flash' && m !== 'review' && m !== 'daily' && m !== 'free').map(mode => {
              const info = EXERCISE_NAMES[mode];
              return (
                <div
                  key={mode}
                  onClick={() => onSelectMode(mode)}
                  className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl p-3 hover:border-[#1f5fbf] transition flex items-center justify-between gap-2.5 cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">{info.icon}</span>
                    <div className="min-w-0">
                      <b className="text-[13px] font-bold text-slate-900 dark:text-slate-100 block leading-snug">{info.title}</b>
                      <span className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] block mt-0.5">{info.desc}</span>
                    </div>
                  </div>
                  <span className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-3 py-1.5 rounded-lg text-[11px] font-bold flex-shrink-0">شروع ▶</span>
                </div>
              );
            })}
          </div>
        )}

        {mainTab === 'grammatik' && (
          <div className="space-y-4">
            {gramSec === null ? (
              <>
                <p className="text-sm text-[#5d6676] dark:text-[#a3adbd] leading-7">
                  گرامر در ۴ دستهٔ اصلی چیده شده — یک دسته را باز کن؛ تمرین‌هایش را به شکل تب بالا می‌بینی.
                </p>
                {GRAMMATIK_CATS.map((sec, si) => (
                  <div
                    key={sec.label}
                    onClick={() => setGramCat(si)}
                    className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl p-4 hover:border-[#1f5fbf] transition cursor-pointer shadow-xs space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xl flex-shrink-0">{sec.icon}</span>
                        <div className="min-w-0">
                          <b className="text-[14px] font-bold text-slate-900 dark:text-slate-100 block leading-snug">{sec.label}</b>
                          <span className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] block mt-0.5">{sec.desc}</span>
                        </div>
                      </div>
                      <span className="text-[#5d6676] dark:text-[#a3adbd] font-bold text-lg">‹</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {sec.tabs.map(t => (
                        <span key={t.id} className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-[#5d6676] dark:text-[#a3adbd]">{t.label}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <>
                <div className="flex items-center justify-between gap-2">
                  <button onClick={() => setGramCat(null)} className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm font-bold">→ همهٔ دسته‌ها</button>
                  <b className="text-sm text-[#5d6676] dark:text-[#a3adbd]">{gramSec.icon} {gramSec.label}</b>
                </div>
                <div className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-2xl p-2 flex gap-1.5 overflow-x-auto">
                  {gramSec.tabs.map(t => (
                    <button
                      key={t.id}
                      onClick={() => openGramTab(t)}
                      className="px-3.5 py-2 rounded-xl text-[12px] font-bold whitespace-nowrap transition flex-shrink-0 bg-slate-100 dark:bg-slate-800 text-[#5d6676] dark:text-[#a3adbd]"
                    >{t.label}</button>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {mainTab === 'schreiben' && (
          <div className="space-y-3">
            {SCHREIBEN_MODES.map(mode => {
              const info = EXERCISE_NAMES[mode];
              return (
                <div
                  key={mode}
                  onClick={() => onSelectMode(mode)}
                  className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl p-3 hover:border-[#1f5fbf] transition flex items-center justify-between gap-2.5 cursor-pointer shadow-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">{info.icon}</span>
                    <div className="min-w-0">
                      <b className="text-[13px] font-bold text-slate-900 dark:text-slate-100 block leading-snug">{info.title}</b>
                      <span className="text-[11px] leading-5 text-[#5d6676] dark:text-[#a3adbd] block mt-0.5">{info.desc}</span>
                    </div>
                  </div>
                  <span className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-3 py-1.5 rounded-lg text-[11px] font-bold flex-shrink-0">شروع ▶</span>
                </div>
              );
            })}
          </div>
        )}


        {showHard && (() => {
          const hardWords = allWords.filter(w => (w.bad || 0) > 3).sort((a, b) => (b.bad || 0) - (a.bad || 0));
          const artCls = (a: string) => a === 'der' ? 'bg-blue-100 text-blue-800' : a === 'die' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800';
          return (
            <PageOverlay icon="🩸" title={`واژه‌های پر اشتباه و سخت (${hardWords.length})`} onClose={() => setShowHard(false)}>
              {hardWords.length === 0 ? (
                <div className="p-4 rounded-xl bg-white dark:bg-[#1b2029] text-center text-sm text-[#5d6676]">هنوز واژه‌ای بیش از ۳ بار اشتباه نشده است.</div>
              ) : (
                <div className="space-y-3 text-right">
                  <button
                    onClick={() => { setShowHard(false); if (onStartHard) onStartHard(hardWords.map(w => w.id)); else onShowToast('شروع تمرین ممکن نشد.', true); }}
                    className="w-full h-12 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-sm shadow-md"
                  >
                    🎯 شروع تمرین اختصاصی واژه‌های سخت ({hardWords.length})
                  </button>
                  <div className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-2xl overflow-hidden">
                    {hardWords.map(w => (
                      <div key={w.id} className="px-3 py-2.5 border-b border-slate-100 dark:border-slate-800 last:border-0 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <span dir="ltr" className="flex items-center gap-2">
                            {w.art && <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${artCls(w.art)}`}>{w.art}</span>}
                            <b className="text-lg font-sans truncate">{w.de}</b>
                          </span>
                          <div className="text-sm text-[#5d6676] dark:text-[#a3adbd] truncate">{w.fa}</div>
                        </div>
                        <div className="text-xs text-left flex-shrink-0 space-y-0.5"><div className="text-red-500 font-bold">❌ {w.bad}</div><div className="text-emerald-600">✅ {w.ok}</div></div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </PageOverlay>
          );
        })()}
      </div>
    );
  }

  if (activeMode === 'flash' && !isFlashConfigured) {
    return (
      <div ref={topRef} className="relative z-0 bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-3xl p-5 md:p-6 shadow-sm space-y-4 text-right max-w-xl mx-auto">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <h2 className="text-base md:text-lg font-bold flex items-center gap-2">
            <span>🃏</span>
            <span>تنظیمات شروع جلسهٔ فلش‌کارت</span>
          </h2>
          <button
            onClick={() => onSelectMode(null)}
            className="text-sm bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 px-3 py-1 rounded-xl font-semibold"
          >
            ↩ بازگشت
          </button>
        </div>

        <div>
          <label className="block text-sm font-bold mb-1.5">تمرین مخصوص یک دستهٔ خاص (اختیاری):</label>
          <select
            value={flashCat}
            onChange={e => setFlashCat(e.target.value)}
            className="w-full bg-slate-50 dark:bg-[#141923] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl px-3.5 py-2.5 text-sm outline-none"
          >
            <option value="">همهٔ دسته‌ها (کلیت واژگان)</option>
            {categories.map(([c, n]) => (
              <option key={c} value={c}>
                {c} ({n} واژه)
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-bold mb-1.5">کدام جهت را می‌خواهید تمرین کنید؟</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              onClick={() => {
                setFlashDir('de');
                setIsFlashConfigured(true);
              }}
              className="py-3 px-3 bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white rounded-xl font-bold text-sm shadow-xs transition"
            >
              🇩🇪 آلمانی ← فارسی
            </button>
            <button
              onClick={() => {
                setFlashDir('fa');
                setIsFlashConfigured(true);
              }}
              className="py-3 px-3 bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white rounded-xl font-bold text-sm shadow-xs transition"
            >
              🇮🇷 فارسی ← آلمانی
            </button>
            <button
              onClick={() => {
                setFlashDir('rand');
                setIsFlashConfigured(true);
              }}
              className="py-3 px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-sm shadow-xs transition"
            >
              🔀 تصادفی مستقل هر کارت
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (activeMode === 'free' && !isFreeStarted) {
    const selectedCount = words.filter(w => !freeCat || w.cat === freeCat).length;

    return (
      <div ref={topRef} className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-3xl p-5 md:p-6 shadow-sm space-y-5 text-right max-w-xl mx-auto">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <h2 className="text-base md:text-lg font-bold flex items-center gap-2"><span>📚</span> مرور آزاد دسته</h2>
          <button onClick={() => onSelectMode(null)} className="text-sm bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 px-3 py-1 rounded-xl font-semibold">↩ بازگشت</button>
        </div>
        <div>
          <label className="block text-sm font-bold mb-1.5">دستهٔ واژگان</label>
          <select value={freeCat} onChange={e => { setFreeCat(e.target.value); }} className="w-full bg-slate-50 dark:bg-[#141923] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl px-3.5 py-2.5 text-sm">
            <option value="">همهٔ دسته‌ها ({words.length} واژه)</option>
            {categories.map(([cat, count]) => <option key={cat} value={cat}>{cat} ({count} واژه)</option>)}
          </select>
          <p className="text-sm text-[#5d6676] dark:text-[#a3adbd] mt-1.5">{selectedCount} واژه در این انتخاب؛ مستقل از سررسید و جعبه‌های لایتنر.</p>
        </div>
        <div>
          <label className="block text-sm font-bold mb-1.5">جهت تمرین</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button onClick={() => { setFreeDir('de'); setFreeRnd(false); }} className={`py-3 px-3 rounded-xl font-bold text-sm transition ${!freeRnd && freeDir === 'de' ? 'bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>🇩🇪 آلمانی ← فارسی</button>
            <button onClick={() => { setFreeDir('fa'); setFreeRnd(false); }} className={`py-3 px-3 rounded-xl font-bold text-sm transition ${!freeRnd && freeDir === 'fa' ? 'bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>🇮🇷 فارسی ← آلمانی</button>
            <button onClick={() => { setFreeRnd(true); }} className={`py-3 px-3 rounded-xl font-bold text-sm transition ${freeRnd ? 'bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>🔀 تصادفی برای هر کارت</button>
          </div>
        </div>
        <button disabled={selectedCount === 0} onClick={() => {
          const freeWords = words.filter(w => !freeCat || w.cat === freeCat);
          setQueue(freeWords.map(w => w.id));
          setCurrentIndex(0);
          setKnownMap({});
          setRevealedCardId(null);
          setIsFreeStarted(true);
        }} className="w-full bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] disabled:opacity-40 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md">
          {selectedCount ? `شروع مرور (${selectedCount} واژه) ▶` : 'این دسته واژه‌ای ندارد'}
        </button>
        {selectedCount === 0 && <p className="text-sm text-amber-700 dark:text-amber-300">این دسته واژه‌ای ندارد. دستهٔ دیگری انتخاب کنید.</p>}
      </div>
    );
  }

  const progressPercent = queue.length > 0 ? Math.round(((currentIndex + 1) / queue.length) * 100) : 0;
  const isFlashType = qMode === 'flash' || qMode === 'free' || qMode === 'review' || qMode === 'daily';
  const isCardRevealed = !!currentItem && revealedCardId === currentItem.id;

  const faVisible = faShown || !!answerResult || !!caseResult;
  const faButton = (
    <button
      type="button"
      onClick={() => setFaShown(true)}
      className="px-3.5 py-1 rounded-full bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/40 text-sky-800 dark:text-sky-200 border border-sky-200 dark:border-sky-800 text-xs font-bold transition"
    >
      👁 مشاهدهٔ ترجمه
    </button>
  );

  if (activeMode === 'hoeren' || activeMode === 'hoeren_new' || activeMode === 'hoeren_archive') {
    return (
      <div className="relative z-0">
        <HoerenTrainer
          initialView={activeMode === 'hoeren_archive' ? 'archive' : activeMode === 'hoeren_new' ? 'creator' : 'menu'}
          onClose={() => onSelectMode(null)}
        />
      </div>
    );
  }
    
  // فریم انتقال بین تمرین‌ها: تا صفِ تمرین جدید ساخته شود، کارتِ «تبریک» کهنه فلش نزند
  if (queueMode !== activeMode) {
    return (
      <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10" aria-hidden="true">
        {renderTabHeader(mainTab === 'grammatik' ? gramStickyBars : undefined)}
        <div className="min-h-[180px]" />
      </div>
    );
  }

  // کارت پایان فقط برای تمرین‌های صف‌محور (فلش‌کارت/جلسهٔ روزانه/مرور و …)؛
  // تمرین‌های خودگردانِ گرامر UI خودشان را دارند و هرگز نباید به این کارت بیفتند.
  if (!isSelfContainedMode(activeMode) && (queue.length === 0 || currentIndex >= queue.length || !currentItem)) {
    return (
      <div ref={topRef} className="relative z-0 bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-3xl p-7 text-center space-y-4 max-w-xl mx-auto shadow-sm">
        <span className="text-4xl block">🎉</span>
        <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">
          تبریک! تمرین به پایان رسید.
        </h3>
        <p className="text-sm text-[#5d6676] dark:text-[#a3adbd]">
          {queue.length === 0 && activeMode === 'act'
            ? 'فعلاً واژهٔ «کاندید فعال‌سازی» نداری. واژه‌های دریافتی را با تمرین دوگانه بالا بیاور تا اینجا بیایند — یا در واژه‌نامه وضعیت چند واژه را دستی به «کاندید» تغییر بده.'
            : queue.length === 0 && (activeMode === 'synant' || activeMode === 'n2v' || activeMode === 'v2n')
            ? activeMode === 'synant'
              ? 'هنوز هیچ واژه‌ای در کتابخانه، مترادف یا متضاد ثبت‌شده ندارد (یا در دسته‌های فعال فعلی نیست). این تمرین از فیلدهای «مترادف» و «متضاد» واژه‌ها استفاده می‌کند.'
              : 'هنوز واژه‌ای با «خانواده واژگانی» مناسب پیدا نشد. این تمرین از خط «خانواده واژگانی: اسم: ... | فعل مرتبط: ...» در یادداشت واژه‌ها استفاده می‌کند.'
            : 'تمامی پرسش‌های این بخش با موفقیت مرور و بررسی شدند.'}
        </p>
        <button
          onClick={() => onSelectMode(null)}
          className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-md"
        >
          بازگشت به مرکز تمرین‌ها
        </button>
      </div>
    );
  }

  return (
    <div ref={topRef} className="relative z-0 space-y-4 text-right max-w-2xl mx-auto pb-10">
      {/* نوار چسبان: تب‌های اصلی + زیرتب‌های گرامر — هنگام اسکرول ثابت می‌مانند */}
      {renderTabHeader(mainTab === 'grammatik' ? gramStickyBars : undefined)}
      <div className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-2xl px-4 py-2.5 flex items-center justify-between gap-2 shadow-xs">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-lg flex-shrink-0">{EXERCISE_NAMES[activeMode]?.icon}</span>
          <span className="font-extrabold text-sm md:text-base text-slate-900 dark:text-slate-100 break-words">
            {EXERCISE_NAMES[activeMode]?.title}
          </span>
          {isFlashType && (currentItem as Word)?.stage !== undefined && (
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs font-bold font-mono">
              جعبه {(currentItem as Word).stage || 1}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2" dir="ltr">
          <IconBtn onClick={() => onSelectMode(null)} title="خروج از تمرین"><X size={18} className="text-red-500" /></IconBtn>
          {!isSelfContainedMode(qMode) && (
            <IconBtn onClick={handleOpenWordProfile} title="شناسنامه واژه"><BookOpen size={18} className="text-violet-500" /></IconBtn>
          )}
          {activeMode !== 'case' && qMode !== 'sent' && !isSelfContainedMode(qMode) && currentItem && (
            <>
              <IconBtn onClick={() => setSentenceModalWord(currentItem as Word)} title="ساخت جمله با این واژه"><PencilLine size={18} className="text-emerald-600" /></IconBtn>
              <IconBtn onClick={() => setShadowWord(currentItem as Word)} title="تمرین تلفظ"><Mic size={18} className="text-rose-600" /></IconBtn>
            </>
          )}
          <IconBtn onClick={() => onOpenHelp(activeMode)} title="راهنمای این تمرین"><HelpCircle size={18} className="text-[#1f5fbf]" /></IconBtn>
          {activeMode === 'wsh' && (
            <IconBtn onClick={() => setFreeOpen(true)} title="تولید جملهٔ آزاد"><Sparkles size={18} className="text-emerald-600" /></IconBtn>
          )}
          {!isSelfContainedMode(qMode) && activeMode !== 'hard' && qMode && (
            <span className="relative">
              <IconBtn onClick={() => { setTimerSecDraft(null); setTimerPopupOpen(true); }} title="تایمر این تمرین" active={timerCfg.on}><TimerIcon size={18} className={timerCfg.on ? 'text-orange-500' : 'text-slate-500'} /></IconBtn>
              {timerCfg.on && <span className="absolute -top-1 -left-1 w-2.5 h-2.5 rounded-full bg-red-500" />}
            </span>
          )}
        </div>
      </div>

      {shadowWord && (
        <ShadowingModal word={shadowWord} onClose={() => setShadowWord(null)} />
      )}
      {sentenceModalWord && (
        <SentenceBuilderModal
          word={sentenceModalWord}
          onClose={() => setSentenceModalWord(null)}
          onShowToast={onShowToast}
        />
      )}

      {/* تولید جملهٔ آزاد — کنار آیکن راهنما در تمرین «جای‌خالی فعل + حرف اضافه (AI)»؛
          با بستن، کاربر دقیقاً به همان جای تمرین برمی‌گردد */}
      {freeOpen && (
        <PageOverlay icon="✒️" title="تولید جملهٔ آزاد" onClose={() => setFreeOpen(false)}>
          <FreeSentencePractice onShowToast={onShowToast} />
        </PageOverlay>
      )}

      {!isSelfContainedMode(qMode) && (
      <div className="space-y-1.5">
        <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] h-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-xs sm:text-sm text-[#5d6676] dark:text-[#a3adbd]">
          <span className="font-medium">
            سؤال {currentIndex + 1} از {queue.length}
            {timerCfg.on && timeLeft !== null && !timerAnswered && (
              <span className="mr-2 px-2.5 py-0.5 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold font-mono animate-pulse">
                ⏱ {Math.max(0, timeLeft)}s
              </span>
            )}
          </span>
          <span>{progressPercent}٪ تکمیل</span>
        </div>
      </div>
      )}

      {/* بدنهٔ تمرین‌های خودگردان گرامر در لایهٔ keep-alive در App رندر می‌شود */}
      {!isGramSelfMode(activeMode) && (
      <div className="bg-white dark:bg-[#1b2029] border border-[#dde1ea] dark:border-[#333b4a] rounded-3xl p-5 md:p-7 shadow-sm space-y-4">
        {activeMode === 'hard' && qMode && (
          <div className="flex justify-center">
            <span className="px-3 py-1 rounded-full bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 text-xs font-bold">
              {currentSub === 'flashFa'
                ? '🎴 فلش‌کارت فارسی ← آلمانی'
                : currentSub === 'flashDe'
                  ? '🎴 فلش‌کارت آلمانی ← فارسی'
                  : `${EXERCISE_NAMES[qMode].icon} ${EXERCISE_NAMES[qMode].title}`}
            </span>
          </div>
        )}

        {isFlashType && (() => {
          const w = currentItem as Word;
          const isFaDir = currentCardDir === 'fa';
          const artCls = w.art === 'der' ? 'text-blue-600 dark:text-blue-400' : w.art === 'die' ? 'text-pink-600 dark:text-pink-400' : 'text-emerald-600 dark:text-emerald-400';
          const speakWord = (e: React.MouseEvent) => { e.stopPropagation(); speak(fullWord(w), { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice }); };
          
          const gradeBtn = (g: 0 | 1 | 2 | 3, label: string, cls: string) => (
            <button onClick={() => handleFlashGrade(g)} className={`${cls} border rounded-xl py-2.5 px-1 flex flex-col items-center leading-tight active:scale-95 transition shadow-xs`}>
              <span className="text-sm font-bold">{label}</span>
              <span className="text-xs font-medium opacity-75 mt-0.5">{intervalPreview(w, g, settings?.ivlMod || 1.0)}</span>
            </button>
          );

          return (
            <div className="space-y-3">
              <div key={currentKey} className="fc-scene transition-all duration-300" style={{ height: 'min(42dvh, 380px)', minHeight: 260 }}>
                <div className={'fc-card h-full transition-transform duration-500 ' + (isCardRevealed ? 'flipped' : '')}>
                  <div className="fc-face rounded-3xl border border-[#dde1ea] dark:border-[#333b4a] shadow-md bg-white dark:bg-[#1b2029] flex flex-col items-center justify-center gap-3 p-6 text-center cursor-pointer select-none" onClick={() => { if (!isCardRevealed) handleRevealCard(); }}>
                    {!isFaDir ? (
                      <>
                        <div className="flex items-center justify-center gap-2 flex-wrap" dir="ltr">
                          {w.art && <span className={`px-3 py-1 rounded-xl font-bold text-xl ${artCls}`}>{w.art}</span>}
                          <span className="text-4xl md:text-5xl font-extrabold font-sans text-slate-900 dark:text-slate-100 break-words">{w.de}</span>
                          <button onClick={speakWord} className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 text-lg flex items-center justify-center transition active:scale-90">🔊</button>
                        </div>
                        {w.pos && <span className="text-sm text-[#5d6676] bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">{w.pos}</span>}
                      </>
                    ) : (
                      <>
                        <div className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-slate-100" dir="rtl">{w.fa}</div>
                        {w.pos && <span className="text-sm text-[#5d6676] bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">{w.pos}</span>}
                      </>
                    )}
                    <span className="absolute bottom-4 text-xs sm:text-sm font-semibold text-[#1f5fbf] dark:text-[#7fb0ff]">برای دیدن پشت کارت بزن ↻</span>
                  </div>

                  <div className="fc-face fc-back rounded-3xl border border-[#dde1ea] dark:border-[#333b4a] shadow-md bg-gradient-to-b from-[#f3f7ff] to-white dark:from-[#182233] dark:to-[#1b2029] p-5 flex flex-col justify-center items-center text-center select-none" onClick={() => { if (isCardRevealed) setRevealedCardId(null); }}>
                    {!isFaDir ? (
                      <div className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-slate-100 mb-3" dir="rtl">{w.fa}</div>
                    ) : (
                      <div className="flex items-center justify-center gap-2 flex-wrap mb-3" dir="ltr">
                        {w.art && <span className={`font-bold text-lg ${artCls}`}>{w.art}</span>}
                        <span className="text-3xl font-extrabold font-sans text-slate-900 dark:text-slate-100">{w.de}</span>
                        <button onClick={speakWord} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-sm flex items-center justify-center">🔊</button>
                      </div>
                    )}

                    {/* روی پشت کارت فقط مثال دوم با ترجمه می‌آید؛ تعریف و مثال اول در «توضیحات بیشتر» هستند (درخواست #۳) */}
                    {w.ex2 && (
                      <div className="w-full max-w-md bg-white dark:bg-[#1b2029] p-3 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1">
                        <div className="flex items-center justify-between gap-2" dir="ltr">
                          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200 text-left">{w.ex2}</p>
                          <button onClick={(e) => { e.stopPropagation(); speak(w.ex2, { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice }); }} className="text-sm">🔊</button>
                        </div>
                        {w.ex2Fa && <p className="text-sm text-slate-600 dark:text-slate-300 text-right font-medium">{w.ex2Fa}</p>}
                      </div>
                    )}
                    {/* فاز ۴ #۷: خط تریک حفظ‌سازی زیر ترجمه و مثال دوم */}
                    {trickOf(w) && (
                      <div className="w-full max-w-md bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 p-2.5 rounded-2xl text-sm font-bold text-amber-800 dark:text-amber-300 leading-6" dir="rtl">
                        🎯 {trickOf(w)}
                      </div>
                    )}
                    <span className="absolute bottom-3 text-xs font-semibold text-slate-400">برای بازگشت به روی کارت کلیک کنید</span>
                  </div>
                </div>
              </div>

              {!isCardRevealed ? (
                <button
                  onClick={handleRevealCard}
                  className="w-full bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md active:scale-[0.99] transition"
                >
                  🔄 {isFaDir ? 'چرخاندن کارت (لغت آلمانی)' : 'چرخاندن کارت (ترجمه)'}
                </button>
              ) : (
                <>
                  <div className="space-y-3 pt-2">
                    <button
                      onClick={() => setMoreOpen(o => !o)}
                      className="w-full flex items-center justify-center gap-1.5 text-sm font-bold text-[#1f5fbf] dark:text-[#7fb0ff] bg-blue-50 dark:bg-slate-800 hover:bg-blue-100 py-2.5 rounded-xl transition shadow-xs"
                    >
                      {moreOpen ? '▲ بستن توضیحات کامل' : '▼ مثال و توضیحات بیشتر (سایر اطلاعات)'}
                    </button>

                    <div className={`overflow-hidden transition-all duration-300 ease-out ${moreOpen ? 'max-h-[3000px] opacity-100' : 'max-h-0 opacity-0'}`}>
                      {moreOpen && renderUnifiedWordCard(w)}
                    </div>

                    {qMode === 'free' ? (
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button onClick={() => handleFreeKnow(0)} className="bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-300 border border-red-200 dark:border-red-800 py-3 rounded-xl font-bold text-sm shadow-xs active:scale-95 transition">❌ هنوز نه</button>
                        <button onClick={() => handleFreeKnow(1)} className="bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 py-3 rounded-xl font-bold text-sm shadow-xs active:scale-95 transition">✅ بلدم</button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-4 gap-1.5 pt-1">
                        {gradeBtn(0, 'دوباره', 'bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-300 border-red-200 dark:border-red-900')}
                        {gradeBtn(1, 'سخت', 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-900')}
                        {gradeBtn(2, 'خوب', 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900')}
                        {gradeBtn(3, 'آسان', 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-900')}
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          );
        })()}

        {qMode === 'art' && (() => {
          const w = currentItem as Word;
          return (
            <div className="space-y-4 text-center">
              <p className="text-sm text-[#5d6676]">آرتیکل درست برای این اسم کدام است؟</p>
              <div className="text-3xl font-extrabold font-sans py-2" dir="ltr">
                {w.de}
              </div>
              <div className="text-base font-semibold text-[#1f5fbf]">{faVisible ? w.fa : faButton}</div>

              {!answerResult ? (
                <div className="grid grid-cols-3 gap-3 pt-2 max-w-sm mx-auto">
                  {['der', 'die', 'das'].map(art => (
                    <button
                      key={art}
                      onClick={() => answerArt(art)}
                      className={`py-3 rounded-2xl font-bold text-lg font-sans transition ${
                        art === 'der' ? 'bg-blue-100 hover:bg-blue-200 text-blue-900' :
                        art === 'die' ? 'bg-pink-100 hover:bg-pink-200 text-pink-900' :
                        'bg-emerald-100 hover:bg-emerald-200 text-emerald-900'
                      }`}
                    >
                      {art}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-3 pt-2">
                  <div className={`p-3 rounded-xl text-base font-bold leading-relaxed ${
                    answerResult.ok ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {answerResult.ok ? '✔ آفرین! درست بود.' : `✘ ${answerResult.msg}`}
                  </div>
                  {renderUnifiedWordCard(w)}
                  <button
                    onClick={advanceQuestion}
                    className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs"
                  >
                    سؤال بعدی ⬅
                  </button>
                </div>
              )}
            </div>
          );
        })()}

        {qMode === 'case' && (() => {
          const q = currentItem as CaseQuestion;
          const bareNoun = q.n.replace(/^(der|die|das)\s+/i, '').trim();
          const remainingHints = Math.max(0, 2 - hintLevel);

          return (
            <div className="space-y-4 text-center">
              <p className="text-sm font-semibold text-[#5d6676]">
                دو جای خالی زیر را کامل کنید (حرف اضافه و آرتیکل):
                <span className="mr-2 px-2.5 py-0.5 rounded-full bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 text-xs font-bold">
                  سطح {(currentItem as CaseQuestion).cs || 1}
                </span>
              </p>

              <div className="text-xl md:text-2xl font-bold font-sans py-2 text-slate-900 dark:text-slate-100" dir="ltr">
                {q.s}
              </div>

              <div className="text-sm text-[#5d6676]">
                کلمه مرجع: <span className="font-bold font-sans" dir="ltr">({bareNoun})</span>
                {' — '}
                {faVisible ? q.fa : faButton}
              </div>

              {!answerResult ? (
                <div className="space-y-3 pt-2 max-w-md mx-auto">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-right">
                    <div>
                      <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                        ۱. حرف اضافه (Preposition):
                      </label>
                      <input
                        type="text"
                        dir="ltr"
                        placeholder="مثلاً auf / in / mit..."
                        value={casePrepInput}
                        onChange={e => setCasePrepInput(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') handleCheckCaseAnswer();
                        }}
                        className="w-full bg-slate-50 dark:bg-[#141923] border-2 border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-center font-bold text-base outline-none font-sans focus:border-[#1f5fbf]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                        ۲. آرتیکل (Article):
                      </label>
                      <input
                        type="text"
                        dir="ltr"
                        placeholder="مثلاً dem / den / die..."
                        value={caseArtInput}
                        onChange={e => setCaseArtInput(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') handleCheckCaseAnswer();
                        }}
                        className="w-full bg-slate-50 dark:bg-[#141923] border-2 border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-center font-bold text-base outline-none font-sans focus:border-[#1f5fbf]"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 pt-1">
                    <button
                      onClick={handleCheckCaseAnswer}
                      className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs flex-1"
                    >
                      بررسی دو پاسخ
                    </button>

                    <button
                      onClick={() => setHintLevel(prev => Math.min(2, prev + 1))}
                      disabled={remainingHints === 0}
                      className={`px-3.5 py-2.5 rounded-xl text-sm font-bold border transition ${
                        remainingHints > 0
                          ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-300'
                          : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                      }`}
                    >
                      💡 راهنمایی ({remainingHints})
                    </button>
                  </div>

                  {hintLevel >= 1 && (
                    <div className="p-2.5 bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-sm text-amber-900 dark:text-amber-200 text-right space-y-1">
                      <p>
                        <b>راهنمایی ۱ (حالت دستوری): </b>
                        <span dir="ltr">{q.c.replace(/\s*\(.*\)\s*/, '').trim()}</span>
                        <span> — جنسیت اسم: </span>
                        <span dir="ltr">{(q.n.match(/^(der|die|das)/i) || ['—'])[0].toLowerCase()}</span>
                      </p>
                      {hintLevel >= 2 && (
                        <p className="border-t border-amber-200/60 pt-1 space-y-0.5">
                          <b>راهنمایی ۲: </b>
                          <span dir="ltr" className="font-mono font-bold tracking-widest">
                            {maskText(q.prepAns, 1)} + {maskText(q.artAns, 1)}
                          </span>
                        </p>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3 pt-2">
                  <div className={`p-3 rounded-xl text-base font-bold leading-relaxed ${
                    answerResult.ok ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {answerResult.msg}
                  </div>
                  {caseResult && !caseResult.prepOk && (
                    <MistakeComparison label="حرف اضافه" user={casePrepInput} expected={q.prepAns} />
                  )}
                  {caseResult && !caseResult.artOk && (
                    <MistakeComparison label="آرتیکل" user={caseArtInput} expected={q.artAns} />
                  )}
                  <div className="p-3 bg-slate-50 dark:bg-[#141923] rounded-xl text-sm text-right space-y-1">
                    <p><b>قاعده:</b> {q.r}</p>
                    <p dir="ltr" className="font-semibold text-slate-800 dark:text-slate-200">{q.ex}</p>
                    <p className="text-[#5d6676]">{q.exFa}</p>
                  </div>
                  <button
                    onClick={advanceQuestion}
                    className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs"
                  >
                    سؤال بعدی ⬅
                  </button>
                </div>
              )}
            </div>
          );
        })()}

        {qMode === 'vmc' && currentItem && (
          <VmcQuestion
            key={currentKey}
            w={currentItem as Word}
            poolWords={words}
            onRecord={(word, mode, grade) => record(word, mode, grade)}
            advance={advanceQuestion}
            speakCfg={{ rate: settings?.rate, vreg: settings?.vreg, voice: settings?.voice }}
          />
        )}

        {(qMode === 'conj' || qMode === 'tense' || qMode === 'cloze' || qMode === 'plural' || qMode === 'dict' || qMode === 'prod' || qMode === 'synant' || qMode === 'n2v' || qMode === 'v2n' || qMode === 'adjdecl' || qMode === 'sent' || isSelfContainedMode(qMode)) && (() => {
          const w = currentItem as Word;
          const remainingHints = Math.max(0, 2 - hintLevel);

          return (
            <div className="space-y-4 text-center">
              {qMode === 'conj' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">صرف فعل برای ضمیر داده‌شده:</p>
                  <div className="text-2xl font-bold font-sans py-1 text-slate-900 dark:text-slate-100" dir="ltr">
                    {P6[conjPron]} _____
                  </div>
                  <div className="text-sm text-[#5d6676] flex flex-wrap items-center justify-center gap-2">
                    <span>
                      مصدر: <span className="font-bold font-sans" dir="ltr">{w.de}</span>
                    </span>
                    {faVisible ? <span>({w.fa})</span> : faButton}
                  </div>
                </div>
              )}

              {qMode === 'tense' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">فعل را به Präteritum یا Perfekt ببرید:</p>
                  <div className="text-2xl font-bold font-sans py-1 text-slate-900 dark:text-slate-100" dir="ltr">
                    {w.de}
                  </div>
                  <div className="text-sm text-[#5d6676]">
                    {faVisible ? <>ترجمه: <span className="font-bold">{w.fa}</span></> : faButton}
                  </div>
                </div>
              )}

              {qMode === 'cloze' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">جای خالی را با کلمه مناسب تکمیل کنید:</p>
                  <div className="text-xl md:text-2xl font-bold font-sans py-2 text-slate-900 dark:text-slate-100 leading-relaxed" dir="ltr">
                    {w.cloze || `${w.de} _____`}
                  </div>
                  <div className="text-sm text-[#5d6676]">{faVisible ? `(${w.fa})` : faButton}</div>
                </div>
              )}

              {qMode === 'plural' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">شکل جمع این اسم را بنویسید:</p>
                  <div className="text-2xl font-bold font-sans py-1" dir="ltr">
                    {fullWord(w)}
                  </div>
                  <div className="text-sm text-[#5d6676]">{faVisible ? `(${w.fa})` : faButton}</div>
                </div>
              )}

              {qMode === 'dict' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">واژه را بشنوید و بنویسید:</p>
                  <button
                    onClick={() => speak(fullWord(w), { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })}
                    className="w-12 h-12 mx-auto rounded-full bg-[#1f5fbf] text-white text-xl flex items-center justify-center shadow-md hover:opacity-95"
                  >
                    🔊
                  </button>
                  <div className="text-sm text-[#5d6676]">{faVisible ? `معنی: ${w.fa}` : faButton}</div>
                </div>
              )}

              {qMode === 'synant' && (() => {
                const isAnt = currentKind === 'ant';
                return (
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-[#5d6676]">
                      {isAnt ? 'متضاد (واژهٔ مخالف)' : 'مترادف (واژهٔ هم‌معنی)'} این واژه را بنویسید:
                    </p>
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-2xl md:text-3xl font-extrabold font-sans" dir="ltr">{fullWord(w)}</span>
                      <button
                        onClick={() => speak(fullWord(w), { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })}
                        className="w-9 h-9 rounded-full bg-[#1f5fbf] text-white text-sm flex items-center justify-center"
                      >
                        🔊
                      </button>
                    </div>
                    <div className="text-base font-semibold text-[#1f5fbf] dark:text-[#7fb0ff]">{faVisible ? w.fa : faButton}</div>
                    <span className={`inline-block px-3 py-0.5 rounded-full text-xs font-bold ${
                      isAnt ? 'bg-rose-100 text-rose-800' : 'bg-sky-100 text-sky-800'
                    }`}>
                      {isAnt ? '↔️ متضاد' : '🟰 مترادف'}
                    </span>
                  </div>
                );
              })()}

              {qMode === 'adjdecl' && (
                <div className="space-y-3">
                  {!adjInfo ? (
                    <div className="space-y-2">
                      <p className="text-sm text-red-700">این سؤال دیگر معتبر نیست (واژه تغییر کرده است).</p>
                      <button onClick={advanceQuestion} className="px-4 py-2 rounded-xl bg-[#1f5fbf] text-white text-sm font-bold">بعدی ←</button>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm font-semibold text-[#5d6676]">
                        شکل درست صفتِ داخل پرانتز را در جای خالی بنویسید (فقط صفت، با پایانهٔ مناسب):
                        <span className="mr-2 px-2.5 py-0.5 rounded-full bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 text-xs font-bold">
                          سطح {adjInfo.item.level}
                        </span>
                      </p>
                      <div dir="ltr" className="text-xl md:text-2xl font-bold font-sans leading-relaxed text-center">
                        {answerResult ? adjInfo.item.full : adjInfo.item.sentence.replace('_____', `_____ (${adjInfo.item.base})`)}
                      </div>
                      <div className="text-base font-semibold text-[#1f5fbf] dark:text-[#7fb0ff]">
                        {faVisible ? (adjInfo.src.fa || w.fa) : faButton}
                      </div>
                    </>
                  )}
                </div>
              )}

              {(qMode === 'n2v' || qMode === 'v2n') && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">
                    {qMode === 'n2v'
                      ? 'فعلِ هم‌خانوادهٔ این اسم را بنویسید (مصدر):'
                      : 'اسمِ هم‌خانوادهٔ این فعل را با آرتیکل بنویسید:'}
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-2xl md:text-3xl font-extrabold font-sans" dir="ltr">
                      {qMode === 'n2v' ? fullWord(w) : w.de}
                    </span>
                    <button
                      onClick={() => speak(qMode === 'n2v' ? fullWord(w) : w.de, { rate: settings?.rate, vreg: settings?.vreg, voiceName: settings?.voice })}
                      className="w-9 h-9 rounded-full bg-[#1f5fbf] text-white text-sm flex items-center justify-center"
                    >
                      🔊
                    </button>
                  </div>
                  <div className="text-base font-semibold text-[#1f5fbf] dark:text-[#7fb0ff]">{faVisible ? w.fa : faButton}</div>
                  <span className="inline-block px-3 py-0.5 rounded-full text-xs font-bold bg-violet-100 text-violet-800">
                    {qMode === 'n2v' ? '🔁 اسم ← فعل' : '🔂 فعل ← اسم'}
                  </span>
                </div>
              )}

              {qMode === 'sent' && (
                <SentencePractice
                  key={currentKey}
                  w={w}
                  faVisible={faShown}
                  faButton={faButton}
                  timeUpSignal={sentTimeUp}
                  onGraded={grade => {
                    setAnswerResult({ ok: grade >= 2 ? 1 : 0, exp: '' });
                    record(w, 'sent', grade);
                  }}
                  onNext={advanceQuestion}
                />
              )}

              {qMode === 'freesent' && (
                <FreeSentencePractice
                  key={currentKey}
                  onShowToast={onShowToast}
                />
              )}
              {qMode === 'schreiben' && (
                <SchreibenCorrector
                  key={currentKey}
                  variant="pruefen"
                  onShowToast={onShowToast}
                />
              )}
              {qMode === 'schreiben_exam' && (
                <SchreibenCorrector
                  key={currentKey}
                  variant="pruefung"
                  onShowToast={onShowToast}
                />
              )}
              {qMode === 'dikt' && <Diktat key={currentKey} words={words} onShowToast={onShowToast} />}
              {qMode === 'errnb' && <ErrorNotebook key={currentKey} onShowToast={onShowToast} />}
              {qMode === 'prod' && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-[#5d6676]">معادل آلمانی را تایپ کنید (با آرتیکل در صورت اسم بودن):</p>
                  <div className="text-2xl md:text-3xl font-extrabold text-[#1f5fbf] dark:text-[#7fb0ff] py-1">
                    {w.fa}
                  </div>
                  <p className="text-sm text-[#5d6676]">نوع کلمه: {w.pos}</p>
                </div>
              )}

              {(qMode === 'sent' || isSelfContainedMode(qMode)) ? null : !answerResult ? (
                <div className="space-y-3 pt-2 max-w-sm mx-auto">
                  <input
                    type="text"
                    dir="ltr"
                    placeholder="پاسخ را اینجا تایپ کنید..."
                    value={userInput}
                    onChange={e => setUserInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') handleCheckAnswer();
                    }}
                    className="w-full bg-slate-50 dark:bg-[#141923] border-2 border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-center font-bold text-base md:text-lg outline-none font-sans"
                  />

                  <div className="flex items-center justify-center gap-2">
                    <button
                      onClick={handleCheckAnswer}
                      className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs flex-1"
                    >
                      بررسی پاسخ
                    </button>

                    <button
                      onClick={() => setHintLevel(prev => Math.min(2, prev + 1))}
                      disabled={remainingHints === 0}
                      className={`px-3.5 py-2.5 rounded-xl text-sm font-bold border transition ${
                        remainingHints > 0
                          ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-300'
                          : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                      }`}
                    >
                      💡 راهنمایی ({remainingHints})
                    </button>
                  </div>

                  {hintLevel > 0 && (() => {
                    const cands =
                      qMode === 'synant'
                        ? splitList(currentKind === 'ant' ? w.ant : w.syn)
                        : qMode === 'n2v' || qMode === 'v2n'
                          ? familyCands(w, qMode)
                          : qMode === 'adjdecl' && adjInfo
                            ? [adjInfo.item.answer]
                            : [];
                    const hint = buildHint(qMode || 'cloze', w, hintLevel, { pron: conjPron, kind: currentKind, cands });
                    return (
                      <div className="p-2.5 bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-sm text-amber-900 dark:text-amber-200 space-y-1">
                        {hint.note && <div>{hint.note}</div>}
                        {hint.mask && (
                          <div dir="ltr" className="font-mono font-bold text-base tracking-widest">
                            {hint.mask}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              ) : (
                <div className="space-y-3 pt-2">
                  <div className={`p-3 rounded-xl text-base font-bold leading-relaxed ${
                    answerResult.ok ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {answerResult.ok ? '✔ درست است! آفرین.' : `✘ ${answerResult.msg || 'پاسخ نادرست است.'}`}
                  </div>

                  {qMode === 'adjdecl' && adjInfo && (
                    <div className="p-3 rounded-xl bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-900 text-sm md:text-base text-violet-900 dark:text-violet-200 text-right leading-relaxed">
                      <div dir="ltr" className="font-bold font-sans mb-1">{adjInfo.item.full}</div>
                      {adjInfo.item.explanation}
                    </div>
                  )}

                  {!answerResult.ok && (
                    <MistakeComparison
                      user={userInput}
                      expected={answerResult.cands && answerResult.cands.length > 0 ? answerResult.cands : answerResult.exp}
                    />
                  )}

                  {renderUnifiedWordCard(w, { hideConj: qMode === 'conj' })}

                  <button
                    onClick={advanceQuestion}
                    className="bg-gradient-to-r from-[#1f5fbf] to-[#6b4fd8] text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-xs"
                  >
                    سؤال بعدی ⬅
                  </button>
                </div>
              )}
            </div>
          );
        })()}
      </div>
      )}

      {timerPopupOpen && qMode && activeMode !== 'hard' && (
        <div
          className="fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-4"
          onClick={() => setTimerPopupOpen(false)}
        >
          <div
            className="w-full max-w-sm bg-white dark:bg-[#1b2029] rounded-2xl border border-[#dde1ea] dark:border-[#333b4a] p-5 space-y-4 text-right shadow-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base">⏱ تایمر «{EXERCISE_NAMES[qMode]?.title}»</h3>
              <button onClick={() => setTimerPopupOpen(false)} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 font-bold" aria-label="بستن">✕</button>
            </div>
            <label className="flex items-center gap-2.5 cursor-pointer text-sm font-semibold select-none">
              <input
                type="checkbox"
                checked={timerCfg.on}
                onChange={e => { const d = parseInt(timerSecDraft ?? '', 10); const sec = Number.isNaN(d) ? timerCfg.sec : Math.max(3, Math.min(600, d)); setTimerSecDraft(null); onUpdateSettings?.({ timers: { ...(settings?.timers || {}), [qMode]: { on: e.target.checked, sec } } }); }}
                className="w-4 h-4 accent-[#1f5fbf]"
              />
              <span>تایمر شمارش معکوس فعال باشد</span>
            </label>
            <div>
              <label className="block text-sm font-bold mb-1.5">مدت زمان هر سؤال (ثانیه)</label>
              <input
                type="number"
                min={3}
                max={600}
                value={timerSecDraft ?? String(timerCfg.sec)}
                onChange={e => setTimerSecDraft(e.target.value.replace(/\D/g, ''))}               
                onBlur={() => { const n = parseInt(timerSecDraft ?? '', 10); if (Number.isNaN(n)) setTimerSecDraft(null); else onUpdateSettings?.({ timers: { ...(settings?.timers || {}), [qMode]: { on: timerCfg.on, sec: Math.max(3, Math.min(600, n)) } } }); }}
                className="w-full bg-slate-50 dark:bg-[#141923] border border-[#dde1ea] dark:border-[#333b4a] rounded-xl px-3 py-2 text-center font-bold text-base outline-none"
              />
              <div className="flex gap-2 mt-2">
                {[10, 20, 30, 60].map(v => (
                  <button
                    key={v}
                    onClick={() => { setTimerSecDraft(null); onUpdateSettings?.({ timers: { ...(settings?.timers || {}), [qMode]: { on: true, sec: v } } }); }}
                    className="flex-1 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-sm font-bold"
                  >
                    {v}s
                  </button>
                ))}
              </div>
            </div>
            <p className="text-sm leading-6 text-[#5d6676] dark:text-[#a3adbd]">
              وقتی زمان تمام شود: در فلش‌کارت پاسخ نشان داده می‌شود و در تمرین‌های نوشتاری یا انتخابی، پاسخ فعلی شما بررسی می‌شود (اگر خالی باشد، اشتباه حساب می‌شود). این تنظیم فقط برای همین تمرین است و ذخیره می‌ماند.
            </p>
          </div>
        </div>
      )}

      {profileModalWord && (() => {
        const inLibrary = words.some(x => x.id === profileModalWord.id);
        const liveWord = words.find(x => x.id === profileModalWord.id) || profileModalWord;
        const notSaved = () => onShowToast('این مورد نمونهٔ آموزشی است و در کتابخانهٔ شما ذخیره نشده است.', true);
        return (
          <WordDetailModal
            word={liveWord}
            onClose={() => setProfileModalWord(null)}
            onEdit={w => {
              if (!inLibrary) return notSaved();
              setProfileModalWord(null);
              onEditWord?.(w);
            }}
            onDelete={w => (inLibrary ? onDeleteWord?.(w) : notSaved())}
            onImageChange={(w, img) => (inLibrary ? onImageChange?.(w, img) : notSaved())}
          />
        );
      })()}
    </div>
  );
};